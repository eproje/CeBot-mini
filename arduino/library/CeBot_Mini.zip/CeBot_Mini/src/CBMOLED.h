#ifndef CBMOLED_h
#define CBMOLED_h



//#include "Arduino.h"
//#include "Print.h"


enum OLEDDISPLAY_COLOR {
  BLACK = 0,
  WHITE = 1,
  INVERSE = 2
};
enum OLEDDISPLAY_TEXT_ALIGNMENT {
  TEXT_ALIGN_LEFT = 0,
  TEXT_ALIGN_RIGHT = 1,
  TEXT_ALIGN_CENTER = 2,
  TEXT_ALIGN_CENTER_BOTH = 3
};

class oledgfx{

};

/*********Class of OLED control***********/
//class CBMOLED : public Print {
class CBMOLED : oledgfx {	
  public:
    bool Flag_Sarj;
	bool Color_Index;
	
	
	void Init();
	//void print();
	void IIC_SetPos(unsigned int x, unsigned int y);
	void setCursor(uint8_t x, uint8_t y);
	void Clear();
    void Clear_Screen(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, unsigned int dat1);
    void Fill_Screen(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, unsigned int dat1);
    void PowerDisplay(int Power);

	//void setColorIndex(bool Color_Number);
    //void drawBitmap(int8_t x, int8_t y, uint8_t Bitmap_Width, uint8_t *Bitmap);	
	/*
	void setColor(OLEDDISPLAY_COLOR color);
    // Draw a pixel at given position
    void setPixel(int16_t x, int16_t y);	
    // Draw the border of a circle
    void drawCircle(int16_t x, int16_t y, int16_t radius);
*/
	/*
    void ShowCN_3216(unsigned int x, unsigned int y, unsigned int N, const int *p);
    void ShowCN_1616(unsigned int x, unsigned int y, unsigned int N, const int *p);
	void ShowCN_1216(unsigned int x, unsigned int y, unsigned int N,const  int *p);
    void ShowCN_168(unsigned int x, unsigned int y, unsigned int N, const int *p);
	void ShowCN_816(unsigned int x, unsigned int y, unsigned int N, const int *p);
	void ShowCN_616(unsigned int x, unsigned int y, unsigned int N, const int *p);
    void ShowPIC(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const int *p);
	void SelectFace(unsigned int i,const int *SmilingFace,const int *LongFace,const int *NormalFace);
    void NumDisplay(int i,const  int *Direction,const  int *Foward,const  int *Left,const  int *Right,const  int *Back,const  int *TimeNumber);
	void Clear_NumDisplay(const  int *Direction, const  int *Foward, const  int *Left, const  int *Right, const  int *Back, const  int *TimeNumber);
	void Follow_NumDisplay(unsigned int DirectionFlag, const  int *Foward, const  int *TimeNumber);
    void DownloadDisplay();	
    void SignalDisplay();
    void BluetoothDisplay();
    void OLED_SignalDisplay(int Flag0,int Flag1,int Flag2,int Flag3,int Flag4);
    void Button_Display(int i, const  int *SmilingFace, const  int *LongFace, const  int *NormalFace, const  int *StartDebug, const  int *Direction, const  int *Foward, const  int *Left, const  int *Right, const  int *Back, const  int *TimeNumber, const  int *SignalNumber);
    void Button_DisplayMaze(const  int *StartDebug,const  int *Maze,const  int *New);
	void Button_Follow(const  int *StartDebug,const int *Bee);
	void DisplayMaze(int i ,const  int *LRBS);
	void OLED_Display(const int *Rollbot,const  int *Sunfounder,const  int *StartDebug);
	void SelectBee(unsigned int i,const int *BeeOne,const int *BeeTwo,const int *BeeThree,const int *BeeFour);
  */
    void WriteCommand(unsigned int ins);
    void WriteData(unsigned int dat);
  private:


  protected:

	
};
/*********Class of LED control***********/
extern CBMOLED Display;
#endif