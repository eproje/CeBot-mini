#ifndef CeBotmini_H
#define CeBotmini_H

//#pragma GCC diagnostic push
//#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC push_options
#pragma GCC optimize ("O0")//optimizasyon kapatilsin
//#pragma GCC pop_options
/*
-Os (Arduino IDE default)
Compiled size: 19,558 bytes
Execution time: 17.8 seconds

-O0 (no optimisation at all!)
Compiled size: 31,382 bytes
Execution time: 44.7 seconds

-O1
Compiled size: 20,428 bytes
Execution time: 17.0 seconds

-O2
Compiled size: 20,500 bytes
Execution time: 12.7 seconds

-O3
Compiled size: 25,550 bytes
Execution time: 12.2 seconds

*/
#define CHIPSET ATmega_168_168P_328P 
#define BOARD_ARDUINO_UNO


/*pinler*/
/*2xDC motor*/
#define PIN_IRIN 2		// IR receiver pin (interrupt)
#define PIN_ECHO 3		// hcsr04 echo pin (interrupt)	
#define PIN_M1DIR 4
#define PIN_M1PWM 5
#define PIN_M2PWM 6
#define PIN_M2DIR 7
#define PIN_BUZZER 8
#define PIN_PowerGood 9	// power / standby control pin
#define PIN_MP3TX 10	// TX pin for JQ6500
#define PIN_TRIG 11		// HCSR04 trigger pin
#define PIN_IROUT 12	// IR transmit  pin
#define PIN_LED 13		// onboard 4xPIXEL led pin	
#define PIN_SENS0 14
#define PIN_SENS1 15
#define PIN_S0 16
#define PIN_S1 17

#define PIN_LDR 20
#define PIN_BTN 21

/*I2C DEVICES*/
//Compass only has one address
#define COMPASS_DEFAULT_ADDRESS (0x1E)  
#define OLED_DEFAULT_ADDRESS    (0x3C)  
 
#define I2C_ERROR                  (-1)

/*INCLUDES*/
	#include <Arduino.h>
	#include <Wire.h>

	#include "CBMRGBLed.h" 	//pixel led kutuphanesi
	//#include "CBMOLED.h"	//oled kutuphanesi
	
	#include "CBMDS1307.h"	//ds1307 kutuphanesi
	#include "TimerOne.h"	//timerone library

	
	#define TIMER_US 1000//50             // 50 uS timer duration 
	#define TICK_COUNTS 100//20//4000        // 200 mS worth of timer ticks
	


	

	/*interrupts*/
	//#define interrupts() sei()
	//#define noInterrupts() cli()
	
	#define int_irrec 0 //IE receiver  
	#define int_echo 1 	//US echo  
	

	/*seri port*/
	#define CBM_BAUD_RATE 115200
	/*ADC */
	/*voltmetre sabitleri*/

	//3v harici
	//#define ADC_Ref 3.0
	//#define ADMUX_Def B00110000

	//5v dahili
	#define ADC_Ref 3.30
	#define ADMUX_Def 0B00010000

	
	/*cizgi sensoru*/
	#define L_black 0
	#define Def_linecolor L_black

    //oled
	#define DISPLAY_WIDTH 128
	#define DISPLAY_HEIGHT 64
	#define LED_BUFFER_SIZE   32
	#define STRING_DISPLAY_BUFFER_SIZE 20//22//20		

	class CB_Mini
	{
	public:
		CB_Mini();
		void Begin(void);
		//bool __attribute__ ((noinline)) i2c_init(void) __attribute__ ((used));
		
		void RunTime(void);//void RunTime(void);
		void DCMotorRun(int motorID,int pwmVal);
		void DCMotorStop(void);
		void LED(uint8_t index, uint8_t red, uint8_t green, uint8_t blue);
		void Buzzer(int note, int beats);
		//void Buzzer(uint16_t frequency, uint32_t duration);
		//void BuzzerTone(int note, int beats);
		void BuzzerStop(void);
		
		unsigned char ShowData[16];
		
		bool getLineSensor(int id);
		unsigned int  getLineSensorValue(int id);
		unsigned int  getLightSensorValue(int id);
		uint8_t  getButton(void);//buton bilgisini getirir
		unsigned int  getButtonPIN(void);//buton girisindeki ADC degerini getirir
		bool getButtonPressed(int index);//secili buton basilimi bilgisini getirir
	

		double getBatteryVoltage(void);
		double getUSBVoltage(void);
		int getTemperature(void);
		double getDistance(void);
		int getCompass(void);
		
		void playMP3(unsigned int fileNumber);

		//ekran fonksiyonlari
		//void setOLEDColor(bool Color_Number);
		
		void clearScreen(void);
		void Show_Power(void);
		void drawICON(int8_t x, int8_t y, uint8_t Bitmap_Width, uint8_t *Bitmap);
		//void drawStr(int16_t X_position, int8_t Y_position, const char *str);
		void drawStr(const char *str);
		void showStr(void);
		void PrintLCD(uint8_t line, char *str);
		void drawLedBuffer(void);
		//variables
		
	
	private:
	//ekran degiskenleri
	  bool b_Color_Index=1;
	  
	  //int16_t i16_Str_Display_X_Position;
	  //int8_t i8_Str_Display_Y_Position;
	  //int16_t i16_Number_of_Character_of_Str;
	  uint8_t u8_Display_Buffer[32];//[LED_BUFFER_SIZE];
	  //char i8_Str_Display_Buffer[STRING_DISPLAY_BUFFER_SIZE];	
		
  
	};
	
	extern CB_Mini robot;
	
#endif //