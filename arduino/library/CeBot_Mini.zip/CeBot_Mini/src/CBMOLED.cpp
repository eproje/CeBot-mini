#include <Arduino.h>
#include <avr/pgmspace.h>
#include "Wire.h"
#include "CBMOLED.h"

//#include <math.h>


#ifndef OLED_DEFAULT_ADDRESS
	#define OLED_DEFAULT_ADDRESS    (0x3C) 
#endif


/*********OLED command writing***********/
void CBMOLED::WriteCommand(unsigned int ins)
{
  //Wire.beginTransmission(0x78 >> 1);//0x78 >> 1
  Wire.beginTransmission(OLED_DEFAULT_ADDRESS);
  Wire.write(0x00);//0x00
  Wire.write(ins);
  Wire.endTransmission();
}
/*********OLED data writing***********/
void CBMOLED::WriteData(unsigned int dat)
{
  //Wire.beginTransmission(0x78 >> 1 );//0x78 >> 1
  Wire.beginTransmission(OLED_DEFAULT_ADDRESS);
  Wire.write(0x40);//0x40
  Wire.write(dat);
  Wire.endTransmission();
}

/*********OLED initialization***********/
void CBMOLED::Init()
{
  Wire.begin();
  Wire.setClock(800000);

  WriteCommand(0xAE);//display off

  WriteCommand(0x00);//set lower column address
  WriteCommand(0x10);//set higher column address

  WriteCommand(0x40);//set the start line of display

  WriteCommand(0xB0);//set page address

  WriteCommand(0x81);
  WriteCommand(0xCF);//0~255��

  WriteCommand(0xA1);//set segment remap

  WriteCommand(0xA6);//normal / reverse

  WriteCommand(0xA8);//multiplex ratio
  WriteCommand(0x3F);//duty = 1/64

  WriteCommand(0xC8);//Com scan direction

  WriteCommand(0xD3);//set display offset
  WriteCommand(0x00);

  WriteCommand(0xD5);//set osc division
  WriteCommand(0x80);

  WriteCommand(0xD9);//set pre-charge period
  WriteCommand(0xF1);

  WriteCommand(0xDA);//set COM pins
  WriteCommand(0x12);

  WriteCommand(0xDB);//set VCOMH
  WriteCommand(0x40);

  WriteCommand(0x8D);//set charge pump enable
  WriteCommand(0x14);

  WriteCommand(0xAF);//display ON
}


void CBMOLED::IIC_SetPos(unsigned int x, unsigned int y)
{
  WriteCommand(0xb0 + y);
  WriteCommand(((x & 0xf0) >> 4) | 0x10); //|0x10
  WriteCommand((x & 0x0f) | 0x00); //|0x01
}
void CBMOLED::setCursor(uint8_t x, uint8_t y) 
{
  IIC_SetPos(x, y);
}

/*
void CBMOLED::setCol(uint8_t col) {
  if (col >= m_displayWidth) return;
  m_col = col;
  col += m_colOffset;
  ssd1306WriteCmd(SSD1306_SETLOWCOLUMN | (col & 0XF));
  ssd1306WriteCmd(SSD1306_SETHIGHCOLUMN | (col >> 4));
}
void CBMOLED::setCursor(uint8_t col, uint8_t row) {
  setCol(col);
  setRow(row);
}
*/
/********* CLS function ***********/
void CBMOLED::Clear() {
/*
#if INCLUDE_SCROLLING
  m_pageOffset = 0;
  setStartLine(0);
#endif  // INCLUDE_SCROLLING
  //Clear_Screen(0, displayWidth() - 1, 0 , displayRows() - 1);
*/  
  Clear_Screen(0, 0, 128, 8, 0x00);
  IIC_SetPos(0, 0);
}


/*********Screen clearing***********/
void CBMOLED::Clear_Screen(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, unsigned int dat1)
{
  unsigned char x, y;
  for (y = y0; y < y1; y++)
  {
    WriteCommand(0xB0 + y);  /*set page address*/
    WriteCommand(0x02);      /*set lower column address*/
    WriteCommand(0x10);      /*set higher column address*/
    for (x = x0; x < x1; x++)
    {
      WriteData(dat1);
    }
  }

}
/*********Display of partial screen control***********/
void CBMOLED::Fill_Screen(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, unsigned int dat1)
{
  unsigned char x, y;
  for (y = y0; y < y1; y++)
  {
    for (x = x0; x < x1; x++)
    {
      IIC_SetPos(x, y);
      WriteData(dat1);
    }
  }
}



/*********Electricity quantity display***********/
/* Batarya gostergesi*/
void CBMOLED::PowerDisplay(int Power)
{


  int ledLevel = map(Power, 350, 440, 0, 14);
//  int ledLevel = map(Power, 0, 1023, 0, 14);
	
  IIC_SetPos(107, 0);
  WriteData(0b00111100);
  WriteData(0b00100100);
  WriteData(0b00100100);
  WriteData(0b11100111);
  WriteData(0b10000001);

	for (int thisLed = 0; thisLed < 14; thisLed++) {
		if (thisLed < ledLevel) {
		  WriteData(0b10111101);
		}
		else {
		  WriteData(0b10000001);
		}
	}
	
  WriteData(0b10000001);
  WriteData(0b11111111);

  IIC_SetPos(100, 0);
  if (Flag_Sarj){
	WriteData(0b00000000);
	WriteData(0b00011100);
	WriteData(0b10011010);
	WriteData(0b01011001);
	WriteData(0b00111000);
	WriteData(0b00000000);

  }else{
	WriteData(0b00000000);
	WriteData(0b00000000);
	WriteData(0b00000000);
	WriteData(0b00000000);
	WriteData(0b00000000);
	WriteData(0b00000000);
  }
 
}


/*
void CBMOLED::setColorIndex(bool Color_Number)
{
    Color_Index = Color_Number;
}
*/
/*
void CBMOLED::drawBitmap(int8_t x, int8_t y, uint8_t Bitmap_Width, uint8_t *Bitmap)
{

	IIC_SetPos(0, 10);
	for(uint8_t k=0;k<Bitmap_Width;k++)
	{
		WriteData(~Bitmap[k]);
	}
}
*/
/*
void CBMOLED::print(){
}
*/
// *********************************************
// Define user object
// *********************************************
class CBMOLED Display;