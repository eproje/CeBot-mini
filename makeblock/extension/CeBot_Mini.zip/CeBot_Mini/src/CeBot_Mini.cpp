#include "CeBot_Mini.h"

	/*
	yapılan degişiklikler
	timer0 8bit  analogWrite(), delay(), millis() and micros() 
	timer1 16bit servo() 
	timer2 8bit  tone()
	*/


	//dahili kutuphaneler
	CBMRGBLed CeBot_Led(13);
	CBMOLED display;

	//degiskenler
	uint8_t _multitask_SQ;	
	uint8_t _adc_SQ;
	uint8_t _Keyb_Data;
	int _Keyb_DataPIN;
	int M1_PWM;
	int M2_PWM;
	uint8_t _beepCounter;

	//sensor degiskenleri
	//int __ADC_Values[16];
	int LsensorData[8]; //line sensor data
	int LightsensorData[4]; //line sensor data
	
	double BatteryVoltage;
	double BoardTemperature;
	double USBVoltage;
	double _Distance1;
	
	
	//hcsr04 icin kullanilan degiskenler
	volatile long CMBV_echo_start = 0;                         // Records start of echo pulse 
	volatile long CMBV_echo_end = 0;                           // Records end of echo pulse
	volatile long CMBV_echo_duration = 0;                      // Duration - difference between end and start
	volatile int trigger_time_count = 0;                  // Count down counter to trigger pulse time	
	
	
	//ekran kontrol 
	
	
	/*FLAGS*/
	bool flag_Pixelrefresh; 
	bool flag_NewKey; 

//*****************************************************************************
//CB_Mini class fonksiyonlari
void CB_Mini::DCMotorRun(int motorID,int pwmVal)
{
	CBM_DCMotorRun(motorID,pwmVal );//call local function
}
void CB_Mini::DCMotorStop(void)
{
	this->DCMotorRun(0,0);
}


void CB_Mini::LED(uint8_t index, uint8_t red, uint8_t green, uint8_t blue){
	CeBot_Led.setColor(index,red,green,blue);
	//CeBot_Led.show();
	flag_Pixelrefresh=true;
}
void CB_Mini::Buzzer(int note, int beats){
	tone(PIN_BUZZER,(long)note,(long)beats);
}
void CB_Mini::BuzzerStop(void){
	noTone(PIN_BUZZER);
}
bool CB_Mini::getLineSensor(int id){
	return 0;//(bool)LsensorData[id];
}
int CB_Mini::getLineSensorValue(int id){
	return (int)LsensorData[id];
}
int CB_Mini::getLightSensorValue(int id){
	return (int)LightsensorData[id];
}
double CB_Mini::getBatteryVoltage(void){
	return (double)BatteryVoltage;
}
double CB_Mini::getUSBVoltage(void){
	return (double)USBVoltage;;
}
double CB_Mini::getTemperature(void){
	return (double)BoardTemperature;
}
//mm olarak mesafe bilgisini getirir
double CB_Mini::getDistance(void){
	return _Distance1;
}
//CeBot mini de buton girisi ADC ye baglidir
uint8_t CB_Mini::getButton(void){
	return (uint8_t)_Keyb_Data;
}
int CB_Mini::getButtonPIN(void){
	return (int)_Keyb_DataPIN;
}
bool CB_Mini::getButtonPressed(int index){
	if (index==_Keyb_Data){
		return true;
	}else{
		return false;
	}
}	
//*****************************************************************************










//*****************************************************************************
//global fonksiyonlar	
	

//acilista yurutulecek otomatik calisan fonksiyondur
void initVariant(void){
	CBM_init();
}

void CBM_init(void)
{
	//cli();
	//pin ayarlari
	pinMode(PIN_LED,OUTPUT); digitalWrite(PIN_BUZZER,0);
	pinMode(PIN_BUZZER,OUTPUT); digitalWrite(PIN_BUZZER,0);
	
	pinMode(PIN_TRIG, OUTPUT);//HCSR04 Trigger pin set to output
	pinMode(PIN_ECHO, INPUT); //HCSR04 echo pin set to input
  
	pinMode(PIN_IROUT, OUTPUT);// pin set to output
	pinMode(PIN_IRIN, INPUT);  //HCSR04 echo pin set to input

	pinMode(PIN_S0, OUTPUT);  //mutiplexer s0
	pinMode(PIN_S1, OUTPUT);  //mutiplexer s1

	pinMode(PIN_SENS0, INPUT);  //analog1
	pinMode(PIN_SENS1, INPUT);  //analog2
	pinMode(PIN_LDR, INPUT);  //analog3
	pinMode(PIN_BTN, INPUT);  //analog4
	
	//seri port
	Serial.begin(CBM_BAUD_RATE);
	while (!Serial) { ; } //Seri baglantiyi bekle
	
	

	CeBot_Led.setColor(0,255,255,255);
    CeBot_Led.show();
	
	
	Wire.begin();
	Wire.setClock(400000);//100000 (standard mode),400000 (fast mode).10000 (low speed mode), 1000000 fast plus,3400000 (high speed mode),
	
	//delay(500);
	display.begin();
	display.show();
	/*
	display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
	display.display();
	display.clearDisplay();
	*/
	_multitask_SQ=0;
	_adc_SQ=0;
	trigger_time_count = TICK_COUNTS; 
	
	//adc
	CBM_adcInit();
	
	
	//interruptlar
	Timer1.initialize(5000); 
	Timer1.initialize(TIMER_US);                        // Initialise timer 1
	Timer1.attachInterrupt( CMB_timerIsr );                 // Attach interrupt to the timer service routine 
	attachInterrupt(int_echo, CMB_echoIsr, CHANGE);  // Attach interrupt to the sensor echo input
	
	//sei();
}

//ADMUX kanal degistirme.
//a. When ADATE or ADEN is cleared.
//b. During vclock cycle after the trigger event.
//c. After a conversion, before the Interrupt Flag used as trigger source is cleared
//REFS1 REFS0 ADLAR – MUX3 MUX2 MUX1 MUX0

void CBM_adcInit(){
/*
  // clear ADLAR in ADMUX (0x7C) to right-adjust the result
  // ADCL will contain lower 8 bits, ADCH upper 2 (in last two bits)
  ADMUX &= B11011111;
  
  // Set REFS1..0 in ADMUX (0x7C) to change reference voltage to the
  // proper source (01)
  ADMUX |= B01000000;
  
  // Clear MUX3..0 in ADMUX (0x7C) in preparation for setting the analog
  // input
  ADMUX &= B11110000;
  
  // Set MUX3..0 in ADMUX (0x7C) to read from AD8 (Internal temp)
  // Do not set above 15! You will overrun other parts of ADMUX. A full
  // list of possible inputs is available in Table 24-4 of the ATMega328
  // datasheet
  ADMUX |= 8;
  // ADMUX |= B00001000; // Binary equivalent
  
  // Set ADEN in ADCSRA (0x7A) to enable the ADC.
  // Note, this instruction takes 12 ADC clocks to execute
  ADCSRA |= B10000000;
  
  // Set ADATE in ADCSRA (0x7A) to enable auto-triggering.
  ADCSRA |= B00100000;
  
  // Clear ADTS2..0 in ADCSRB (0x7B) to set trigger mode to free running.
  // This means that as soon as an ADC has finished, the next will be
  // immediately started.
  ADCSRB &= B11111000;
  
  // Set the Prescaler to 128 (16000KHz/128 = 125KHz)
  // Above 200KHz 10-bit results are not reliable.
  ADCSRA |= B00000111;
  
  // Set ADIE in ADCSRA (0x7A) to enable the ADC interrupt.
  // Without this, the internal interrupt will not trigger.
  ADCSRA |= B00001000;
  
  // Enable global interrupts
  // AVR macro included in <avr/interrupts.h>, which the Arduino IDE
  // supplies by default.
  //sei();
  
  // Kick off the first ADC
  //readFlag = 0;
  // Set ADSC in ADCSRA (0x7A) to start the ADC conversion
  ADCSRA |=B01000000;
*/  
  ADMUX = B01110000;
  ADCSRB = B11111000;
  ADCSRA =B11001111;

}
//adcsra
//ADEN ADSC ADATE ADIF ADIE ADPS2 ADPS1 ADPS0
//adcsrb
//– ACME – – – ADTS2 ADTS1 ADTS0
 
// --------------------------
// INTERRUPT
void CMB_echoIsr(void)
{
  switch (digitalRead(PIN_ECHO))                    // Test to see if the signal is high or low
  {
    case HIGH:                                      // High so must be the start of the echo pulse
      CMBV_echo_end = 0;                                 // Clear the end time
      CMBV_echo_start = micros();                        // Save the start time
      break;
      
    case LOW:                                       // Low so must be the end of hte echo pulse
      CMBV_echo_end = micros();                          // Save the end time
      CMBV_echo_duration = CMBV_echo_end - CMBV_echo_start;        // Calculate the pulse duration
	  if (CMBV_echo_duration > 17100)
	  {
		CMBV_echo_duration = 0;//hatali olcum olustu
	  }	  
	  
	  _Distance1=(double)((double)CMBV_echo_duration / (double)57);
      break;
  }
}
// --------------------------
// trigger_pulse() called every 50 uS to schedule trigger pulses.
// Generates a pulse one timer tick long.
// Minimum trigger pulse width for the HC-SR04 is 10 us. This system
// delivers a 50 uS pulse.
// --------------------------

void trigger_pulse()
{
      static volatile int state = 0;                 // State machine variable


      if (!(--trigger_time_count))                   // Count to 200mS
      {                                              // Time out - Initiate trigger pulse
         trigger_time_count = TICK_COUNTS;           // Reload
         state = 1;                                  // Changing to state 1 initiates a pulse
      }
    
      switch(state)                                  // State machine handles delivery of trigger pulse
      {
        case 0:                                      // Normal state does nothing
            break;
        
        case 1:                                      // Initiate pulse
           digitalWrite(PIN_TRIG, HIGH);              // Set the trigger output high
           state = 2;                                // and set state to 2
           break;
        
        case 2:                                      // Complete the pulse
        default:      
           digitalWrite(PIN_TRIG, LOW);               // Set the trigger output low
           state = 0;                                // and return state to normal 0
           break;
     }
}


// INTERRUPT
void CMB_timerIsr(void)
{
	CBM_CMultitask();
}
//bu fonksiyon kullanicidan bagimsiz kontrolleri gerceklestirir 
void CBM_CMultitask(void){
	switch(_multitask_SQ)
	{
		case 0:
			//digitalWrite(PIN_BUZZER,digitalRead(PIN_BUZZER)-1);
			digitalWrite(PIN_IROUT,digitalRead(PIN_IROUT)-1);
		break;
		case 1:
			trigger_pulse();
		break;
		case 2:
		
		break;
		case 3:
		
		break;
		
		default:
			_multitask_SQ=250;
		break;
	}
	_multitask_SQ++;
	if (_multitask_SQ > 250) { _multitask_SQ=0;}
}
/*
void CBM_Buzzer(void)
{

}
*/
void CBM_Beep(uint8_t tick)
{
	_beepCounter=tick;
}


void CBM_adcValueToLocalVar(uint8_t chid){
	int analogVal = ADCL | (ADCH << 8);
	int _Keyb_DataTemp;
	//__ADC_Values[_adc_SQ]=analogVal;
	switch(chid)
	{
		case 4://ldr1
			LightsensorData[0]=(int)analogVal;
		break;
		case 9://ldr2
			LightsensorData[1]=(int)analogVal;
		break;
		case 14://ldr3
			LightsensorData[2]=(int)analogVal;
		break;
		case 19://ldr4
			LightsensorData[3]=(int)analogVal;
		break;


		case 5: //btn
			_Keyb_DataPIN=(int)analogVal;//keyboard pininden okunan analog bilgisini
			//_Keyb_Data
			if (_Keyb_DataPIN >1000){
				flag_NewKey=false;//hic tusa basili degil
				_Keyb_Data=0;
			}else{
				_Keyb_DataTemp=0;
				if (flag_NewKey==false){
					/*
					if (_Keyb_DataPIN < 10) _Keyb_DataTemp=1;//0 	E
					if (_Keyb_DataPIN > 500 & _Keyb_DataPIN < 520) _Keyb_DataTemp=2;//510	X
					if (_Keyb_DataPIN > 800 & _Keyb_DataPIN < 825) _Keyb_DataTemp=3;//818	U
					if (_Keyb_DataPIN > 845 & _Keyb_DataPIN < 860) _Keyb_DataTemp=4;//852	D
					if (_Keyb_DataPIN > 680 & _Keyb_DataPIN < 695) _Keyb_DataTemp=5;//682	L
					if (_Keyb_DataPIN > 760 & _Keyb_DataPIN < 775) _Keyb_DataTemp=6;//767	R
					*/
					if (_Keyb_DataPIN < 860)_Keyb_DataTemp=4;
					if (_Keyb_DataPIN < 825)_Keyb_DataTemp=3;
					if (_Keyb_DataPIN < 775)_Keyb_DataTemp=6;
					if (_Keyb_DataPIN < 695)_Keyb_DataTemp=5;
					if (_Keyb_DataPIN < 520)_Keyb_DataTemp=2;
					if (_Keyb_DataPIN < 10)_Keyb_DataTemp=1;
					
					
					if (_Keyb_DataTemp > 0){
						flag_NewKey=true;
						_Keyb_Data=_Keyb_DataTemp;
						//interrupt
						CBM_Beep(5);
						//tone(PIN_BUZZER,(long)note,(long)beats);
					}
					
				}
			}
			//burada buton kesmesi olusturulur
		break;
		case 10://boardtemperature
			BoardTemperature=CMB_Termistor(analogVal);
		break;
		
		case 15://battery voltage
			BatteryVoltage=CMB_Voltmeter(analogVal);
		break;
		case 20://USB voltage
			USBVoltage=CMB_Voltmeter(analogVal);
		break;


		case 2://sag1
			LsensorData[2]=analogVal;
		break;
		case 7://sag2
			LsensorData[3]=analogVal;
		break;
		case 3://sol1
			LsensorData[0]=analogVal;
		break;
		case 8://sol2
			LsensorData[1]=analogVal;
		break;
		case 13://on sol
			LsensorData[4]=analogVal;
		break;
		case 18://arka sol
			LsensorData[6]=analogVal;
		break;
		case 12://on sag
			LsensorData[5]=analogVal;
		break;
		case 17://arka sag
			LsensorData[7]=analogVal;
		break;

		
		/**/
		case 1:
			if (_beepCounter > 0){
				digitalWrite(PIN_BUZZER,digitalRead(PIN_BUZZER)-1);
				_beepCounter--;
				if (_beepCounter == 1) digitalWrite(PIN_BUZZER,0);
				
			}
		break;
		case 6:
			//pixel led tazeleme islemi kod ritmini korumak icin kesme ile yapildi
			if (flag_Pixelrefresh){
				CeBot_Led.show();
				flag_Pixelrefresh=false;
			}
	
		break;
		
		case 11:
		break;
		
		case 16:
			//digitalWrite(PIN_BUZZER,digitalRead(PIN_BUZZER)-1);
		break;
		/**/
		default:

		break;
	}
	
}
// INTERRUPT
// ADC

 // Interrupt service routine for the ADC completion
ISR(ADC_vect){
  //
	// Done reading
	// Must read low first
	//analogVal = ADCL | (ADCH << 8);
	CBM_adcValueToLocalVar(_adc_SQ);

	ADMUX &= B11010000;//ch0
	
	
	_adc_SQ++;
	switch (_adc_SQ)
	{
		case 0:
		break;
		
		case 1://00
			digitalWrite(PIN_S1,0);  digitalWrite(PIN_S0,0);
		break;

		case 2://00
			ADMUX |= B00000000;//ch0 line merkez sag (A0)
		break;
		case 3://00
			ADMUX |= B00000001;//ch0 line merkez sol (A1)
		break;
		case 4://00
			ADMUX |= B00000110;// ldr1 (A6)
		break;
		case 5://00
			ADMUX |= B00000111;// BTN (A7)
		break;
		
		case 6://01
			digitalWrite(PIN_S1,0);  digitalWrite(PIN_S0,1);
		break;
		case 7://01
			ADMUX |= B00000000;//line yan sag (A0)
		break;
		case 8://01
			ADMUX |= B00000001;// line yan sol (A1)
		break;
		case 9://01
			ADMUX |= B00000110;//LDR2(A6)
		break;
		case 10://01
			ADMUX |= B00000111;//temperature (A7)
		break;
		
		case 11://10
			digitalWrite(PIN_S1,1);  digitalWrite(PIN_S0,0);
		break;
		case 12://10
			ADMUX |= B00000000;//line on sag (A0)
		break;
		case 13://10
			ADMUX |= B00000001;//line on sol (A1)
		break;
		case 14://10
			ADMUX |= B00000110;//LDR3 (A6)
		break;
		case 15://10
			ADMUX |= B00000111;//battery voltage (A7)
		break;
		
		case 16://11
			digitalWrite(PIN_S1,1);  digitalWrite(PIN_S0,1);
		break;
		case 17://11
			ADMUX |= B00000000;//ch0 line arka sag (A0)
		break;
		case 18://11
			ADMUX |= B00000001;//ch0 line arka sol (A1)
		break;
		case 19://11
			ADMUX |= B00000110;//LDR4 (A6)
		break;
		case 20://11
			ADMUX |= B00000111;//USB voltage (A7)
		break;
		
		
		default:
			digitalWrite(PIN_S1,0);  digitalWrite(PIN_S0,0);
			_adc_SQ=0;
			
		break;
	}
	
	

  
  // Not needed because free-running mode is enabled.
  // Set ADSC in ADCSRA (0x7A) to start another ADC conversion
  // delayus(10);
   ADCSRA |= B01000000;//set adc start bit
  
} 
  
double CMB_Termistor(int aVal){
	// 5V - NTC(4k7) - 10k - gnd
	double db_0;
	db_0 = log(((10240000 / aVal) - 10000));
	db_0 = 1 / (0.001129148 + (0.000234125 + (0.0000000876741 * db_0 * db_0)) * db_0);
	db_0 = db_0 - 273.15;
	return db_0;
}  
/*
double CMB_Termistor(int aVal){
	// 5V - NTC(10k) - 10k - gnd
	double sicaklik;
	sicaklik = log(((10240000 / aVal) - 10000));
	sicaklik = 1 / (0.001129148 + (0.000234125 + (0.0000000876741 * sicaklik * sicaklik)) * sicaklik);
	sicaklik = sicaklik - 273.15;
	return sicaklik;
}    
	// 5V - NTC - 10k - gnd
	//float reading ;
	//reading = analogVal ;
	//reading = (1023 / reading)  - 1;     // (1023/ADC - 1) 
	//reading = 10000 / reading;  // 10K / (1023/ADC - 1)

*/  

//voltmetre hesaplama
//vin 5.00
//r1 4k7
//r2 4k7
/*
*/
double CMB_Voltmeter(int aVal){
	double db_0;
	db_0 = (aVal * 5.00) / 1024.00;
	db_0 = db_0 / 0.5; 
	if (db_0 < 0.09)//condition 
	{
     db_0=0.00;
	} 	
	return db_0;	
}
/*
int analogInput = 1;
float Vout = 0.00;
float Vin = 0.00;
float R1 = 100000.00; // resistance of R1 (100K) 
float R2 = 10000.00; // resistance of R2 (10K) 
int val = 0;
void setup(){
   pinMode(analogInput, INPUT); //assigning the input port
   Serial.begin(9600); //BaudRate
}
void loop(){
   
   val = analogRead(analogInput);//reads the analog input
   Vout = (val * 5.00) / 1024.00; // formula for calculating voltage out i.e. V+, here 5.00
   Vin = Vout / (R2/(R1+R2)); // formula for calculating voltage in i.e. GND
   if (Vin<0.09)//condition 
   {
     Vin=0.00;//statement to quash undesired reading !
  } 
Serial.print("\t Voltage of the given source = ");
Serial.print(Vin);
delay(1000); //for maintaining the speed of the output in serial moniter
}

*/








/*motor fonksiyonlari*/
void CBM_DCMotorRun(int motorID,int pwmVal )
{
	bool dir=0;
	pinMode(PIN_M1DIR,OUTPUT);
	pinMode(PIN_M2DIR,OUTPUT);

	if (pwmVal<0){
		pwmVal=pwmVal * -1;
		dir=0;
	}else{
		dir=1;
	}

	if (pwmVal>250){pwmVal=250;}

	switch (motorID)
	{
	case 1:
		digitalWrite(PIN_M1DIR,dir);
		analogWrite(PIN_M1PWM,pwmVal);
		M1_PWM=pwmVal;
	break;
	
	case 2:
		digitalWrite(PIN_M2DIR,dir - 1);
		analogWrite(PIN_M2PWM,pwmVal);
		M2_PWM=pwmVal;
	break;
	
	default:
		digitalWrite(PIN_M1DIR,dir);
		analogWrite(PIN_M1PWM,pwmVal);
		M1_PWM=pwmVal;
		digitalWrite(PIN_M2DIR,dir - 1);
		analogWrite(PIN_M2PWM,pwmVal);
		M2_PWM=pwmVal;
	break;
	}
}
/*
void CBM_DCMotorStop(void){
	
}

void CBM_Move(){
	
}
*/

/*pixel led fonksiyonlari*/
void CBM_PixelInit(void){
	CeBot_Led.setColor(0,0,0,0);
	CeBot_Led.show();
}
void CBM_PixelSet(uint8_t index, uint8_t red, uint8_t green, uint8_t blue){
	CeBot_Led.setColor(index,red,green,blue);
	CeBot_Led.show();
}
void CBM_PixelShow(void){
	CeBot_Led.show();
}


/*oled*/
/*oled fonksiyonlari*/
void CBM_DisplayInit(void){

}
void CBM_DisplayClear(void){

}




