//#include <avr/wdt.h>
#include <Arduino.h>
#include <Wire.h>
	
#include "CeBot_Mini.h"

	//dahili fonksiyonlar
	

	/*fonksiyonlar*/
	/*main*/
	
	/*I2C functions*/
	//void  i2c_stop(void);
	
	void CBM_init(void);
	//void CBM_Beep(uint8_t tick);
	/*pixel led*/
	//void CBM_PixelInit(void);//oto init yapildi
	//void CBM_PixelSet(uint8_t index, uint8_t red, uint8_t green, uint8_t blue);
	//void CBM_PixelShow(void);
	/*oled*/
	//void CBM_DisplayInit(void);
	/*motor*/
	void CBM_DCMotorRun(int motorID,int pwmVal);
	void CBM_DCMotorStop(void);
	/*hcsr04*/
	//double CBM_GetDistance(void);
	/**/
	//static int CMB_GetCompass(void);
	//void   CMB_Compass_Begin();

	
	double CBM_GetBatteryVoltage(void);
	static int CMB_Termistor();
	double CMB_Voltmeter(unsigned int aVal);
	double CBM_GetTemperature(void);
	
	//void CBM_adcValueToLocalVar(uint8_t chid);
	
	void CBM_adcInit();
	/**/
	void CMB_timerIsr(void);
	void CMB_echoIsr(void);
	
	void CBM_CMultitask(void);



	//mp3 fonksiyonlari
	//mp3 player icin seri baglanti
	#include "SendOnlySoftwareSerial.h"
	SendOnlySoftwareSerial MP3_port(PIN_MP3TX);  // Tx pin
	//veya
	//#include <SoftwareSerial.h>
	//SoftwareSerial MP3_port(9,PIN_MP3TX);  // Tx pin

	void  MP3sendCommand(byte command, byte arg1, byte arg2);
	void  MP3reset();
	void  MP3play();
	void  MP3setVolume(byte volumeFrom0To30);
	void  MP3playFile(unsigned int fileNumber);	
	




	
	/*
	yapılan degişiklikler
	timer0 8bit  analogWrite(), delay(), millis() and micros() 
	timer1 16bit servo() 
	timer2 8bit  tone()
	*/

	
	//degiskenler
	static volatile uint8_t RT_Squencer;
	
	static volatile uint8_t _multitask_SQ;	
	static volatile uint8_t _adc_SQ;
	static volatile uint8_t _Keyb_Data;
	static volatile uint8_t _Keyb_DataTemp;
	static volatile int _Keyb_DataPIN;
	
	
	static volatile int M1_PWM;
	static volatile int M2_PWM;
	
	//static volatile uint8_t _beepCounter;

	//sensor degiskenleri
	static volatile unsigned int _ADC_Values[21];
	static volatile int LsensorData[8]; //line sensor data
	static volatile int LightsensorData[4]; //line sensor data
	


	
	
	//hcsr04 icin kullanilan degiskenler
	static volatile long CMBV_echo_start = 0;                    // Records start of echo pulse 
	static volatile long CMBV_echo_end = 0;                      // Records end of echo pulse
	static volatile long CMBV_echo_duration = 0;                 // Duration - difference between end and start
	static volatile int trigger_time_count = 0;                  // Count down counter to trigger pulse time	
	
	//ekran kontrol 
	
	//compass variables
	const int x_offset = 0;//30;
	const int y_offset = 0;//128;
	const int z_offset = 0;

	
	
	/*FLAGS*/
	static volatile bool flag_Pixelrefresh; 
	static volatile bool flag_NewKey; 
	//bool Flag_CompassCalibration;


	//temprories
	static volatile double db_0;
	static volatile unsigned int analogVal ;






//*****************************************************************************
//global fonksiyonlar	



//acilista yurutulecek otomatik calisan fonksiyondur
void initVariant(void){
	CBM_init();
}

void CBM_init(void)
{
	//wdt_reset();
	//pin ayarlari

  DDRB = 0B00111111;
  DDRC = 0B00001100;
  DDRD = 0B11110010;


/*	
	pinMode(PIN_PowerGood,OUTPUT); digitalWrite(PIN_PowerGood,0);
	
	pinMode(PIN_LED,OUTPUT); digitalWrite(PIN_LED,0);
	pinMode(PIN_BUZZER,OUTPUT); digitalWrite(PIN_BUZZER,0);
	
	pinMode(PIN_IROUT, OUTPUT);// pin set to output
	digitalWrite(PIN_IROUT,0);

	pinMode(PIN_TRIG, OUTPUT);//HCSR04 Trigger pin set to output
	pinMode(PIN_ECHO, INPUT); //HCSR04 echo pin set to input
  
	
	pinMode(PIN_IRIN, INPUT);  //HCSR04 echo pin set to input

	pinMode(PIN_S0, OUTPUT);  //mutiplexer s0
	pinMode(PIN_S1, OUTPUT);  //mutiplexer s1

	pinMode(PIN_SENS0, INPUT);  //analog1
	pinMode(PIN_SENS1, INPUT);  //analog2
	pinMode(PIN_LDR, INPUT);  //analog3
	pinMode(PIN_BTN, INPUT);  //analog4

*/
	//acilista tum ledler beyaz yansin
	CeBot_Led.begin();
	CeBot_Led.setColor(0,255,255,255);
    CeBot_Led.show();

	//seri port baslati lsin
	Serial.begin(CBM_BAUD_RATE);
	Serial.println("CeBot-mini v1.0 2019");
	while (!Serial) { ; } //Seri baglantiyi bekle
	delay(250);

	
	Wire.begin();
	Wire.setClock(800000);//100000 (standard mode),400000 (fast mode).10000 (low speed mode), 1000000 fast plus,3400000 (high speed mode),
	
	RTC.startClock();
	
	
	//mp3 portu baslatilsin
	MP3_port.begin(9600);
	MP3reset();
	MP3setVolume(20);
	//MP3playFile(4);

	
	
	//rtc islemleri
	//RTC.getTime();
	//delay(500);
	//Display.begin();
	//Display.cls();
	//Display.show();
	
	Display.Init();
	Display.Clear();
	//Display.PowerDisplay(250);
	Display.drawStr("CeBot");
	//Display.PrintLCD(6,"mini1.0");
	//Display.PrintLCD(7," ");
	delay(1000);
	
	//compass
	//CMB_Compass_Begin();
	Wire.beginTransmission(COMPASS_DEFAULT_ADDRESS); //open communication with HMC5883
	Wire.write(0x02); //select mode register
	Wire.write(0x00); //continuous measurement mode
	Wire.endTransmission();
	
	//adc ayarlari
	_multitask_SQ=0;
	_adc_SQ=0;
	//distance
	trigger_time_count = TICK_COUNTS; 
	
	//adc
	CBM_adcInit();
	//onay sesi
	tone(8,700,200);
	Serial.println("Ready");
	
	
	//interruptlar
	//Timer1.initialize(5000); 
	//Timer1.initialize(TIMER_US);                     // Initialise timer 1
	//Timer1.attachInterrupt( CMB_timerIsr );          // Attach interrupt to the timer service routine 
	attachInterrupt(int_echo, CMB_echoIsr, CHANGE);  // Attach interrupt to the sensor echo input
	
	//interrupts();

}

//ADMUX kanal degistirme.
//a. When ADATE or ADEN is cleared.
//b. During vclock cycle after the trigger event.
//c. After a conversion, before the Interrupt Flag used as trigger source is cleared
//REFS1 REFS0 ADLAR – MUX3 MUX2 MUX1 MUX0

void CBM_adcInit(){
/*
  // clear ADLAR in ADMUX (0x7C) to right-adjust the result
  // ADCL will contain lower 8 bits, ADCH upper 2 (in last two bits)
  ADMUX &= B11011111;
  
  // Set REFS1..0 in ADMUX (0x7C) to change reference voltage to the
  // proper source (01)
  ADMUX |= B01000000;
  
  // Clear MUX3..0 in ADMUX (0x7C) in preparation for setting the analog
  // input
  ADMUX &= B11110000;
  
  // Set MUX3..0 in ADMUX (0x7C) to read from AD8 (Internal temp)
  // Do not set above 15! You will overrun other parts of ADMUX. A full
  // list of possible inputs is available in Table 24-4 of the ATMega328
  // datasheet
  ADMUX |= 8;
  // ADMUX |= B00001000; // Binary equivalent
  
  // Set ADEN in ADCSRA (0x7A) to enable the ADC.
  // Note, this instruction takes 12 ADC clocks to execute
  ADCSRA |= B10000000;
  
  // Set ADATE in ADCSRA (0x7A) to enable auto-triggering.
  ADCSRA |= B00100000;
  
  // Clear ADTS2..0 in ADCSRB (0x7B) to set trigger mode to free running.
  // This means that as soon as an ADC has finished, the next will be
  // immediately started.
  ADCSRB &= B11111000;
  
  // Set the Prescaler to 128 (16000KHz/128 = 125KHz)
  // Above 200KHz 10-bit results are not reliable.
  ADCSRA |= B00000111;
  
  // Set ADIE in ADCSRA (0x7A) to enable the ADC interrupt.
  // Without this, the internal interrupt will not trigger.
  ADCSRA |= B00001000;
  
  // Enable global interrupts
  // AVR macro included in <avr/interrupts.h>, which the Arduino IDE
  // supplies by default.
  //sei();
  
  // Kick off the first ADC
  //readFlag = 0;
  // Set ADSC in ADCSRA (0x7A) to start the ADC conversion
  ADCSRA |=B01000000;
*/  

  ADMUX = ADMUX_Def;
  ADCSRB = B11111000;
  ADCSRA = B11001111;

}
//adcsra
//ADEN ADSC ADATE ADIF ADIE ADPS2 ADPS1 ADPS0
//adcsrb
//– ACME – – – ADTS2 ADTS1 ADTS0
 
// --------------------------
// INTERRUPT
void CMB_echoIsr(void)
{
  switch (digitalRead(PIN_ECHO))                    // Test to see if the signal is high or low
  {
    case HIGH:                                      // High so must be the start of the echo pulse
      CMBV_echo_end = 0;                                 // Clear the end time
      CMBV_echo_start = micros();                        // Save the start time
      break;
      
    case LOW:                                       // Low so must be the end of hte echo pulse
      CMBV_echo_end = micros();                          // Save the end time
      CMBV_echo_duration = CMBV_echo_end - CMBV_echo_start;        // Calculate the pulse duration
	  if (CMBV_echo_duration > 17100)
	  {
		CMBV_echo_duration = 0;//hatali olcum olustu
	  }	  
	  
	  _Distance1=(double)((double)CMBV_echo_duration / (double)57);
	  
      break;
  }
  
digitalWrite(PIN_IROUT,digitalRead(PIN_IROUT)-1);

}
// --------------------------
// trigger_pulse() called every 50 uS to schedule trigger pulses.
// Generates a pulse one timer tick long.
// Minimum trigger pulse width for the HC-SR04 is 10 us. This system
// delivers a 50 uS pulse.
// --------------------------

void trigger_pulse()
{
      static volatile int state = 0;                 // State machine variable

      if (!(--trigger_time_count))                   // Count to 200mS
      {                                              // Time out - Initiate trigger pulse
         trigger_time_count = TICK_COUNTS;           // Reload
         state = 1;                                  // Changing to state 1 initiates a pulse
      }
    
      switch(state)                                  // State machine handles delivery of trigger pulse
      {
        case 0:                                      // Normal state does nothing
            break;
        
        case 1:                                      // Initiate pulse
           digitalWrite(PIN_TRIG, HIGH);              // Set the trigger output high
           state = 2;                                // and set state to 2
		   break;
        
        case 2:                                      // Complete the pulse
        default:      
           digitalWrite(PIN_TRIG, LOW);               // Set the trigger output low
           state = 0;                                // and return state to normal 0
           break;
     }

}


// INTERRUPT
/*
void CMB_timerIsr(void)
{
	CBM_CMultitask();
}
*/
//bu fonksiyon kullanicidan bagimsiz kontrolleri gerceklestirir 
//void CBM_CMultitask(void) __attribute__((optimize("-O0")));
void CBM_CMultitask(void){
	
	trigger_pulse();
	
	_multitask_SQ++;
	switch(_multitask_SQ)
	{

		case 1:
			
			//digitalWrite(PIN_BUZZER,digitalRead(PIN_BUZZER)-1);
			//digitalWrite(PIN_IROUT,digitalRead(PIN_IROUT)-1);
			
		break;
		
		case 2:
		
			_Keyb_DataPIN=_ADC_Values[5];;//keyboard pininden okunan analog bilgisini
			//_Keyb_Data
			if (_Keyb_DataPIN >1020){
				flag_NewKey=false;//hic tusa basili degil
				_Keyb_Data=0;
			}else{
				_Keyb_DataTemp=0;
				if (flag_NewKey==false){
					if (_Keyb_DataPIN < 1015){_Keyb_DataTemp=4;}//d
					if (_Keyb_DataPIN < 980){_Keyb_DataTemp=3;}//u
					if (_Keyb_DataPIN < 920){_Keyb_DataTemp=6;}//r
					if (_Keyb_DataPIN < 820){_Keyb_DataTemp=5;}//l
					if (_Keyb_DataPIN < 620){_Keyb_DataTemp=2;}//x
					if (_Keyb_DataPIN < 10) {_Keyb_DataTemp=1;}//e
					
					
					if (_Keyb_DataTemp > 0){
						flag_NewKey=true;
						_Keyb_Data=(uint8_t)_Keyb_DataTemp;
						//interrupt
						//CBM_Beep(5);
						tone(PIN_BUZZER,2000,5);
					}
					
				}
			}
			//burada buton kesmesi olusturulur		
			
		break;
		case 3:
			BatteryVoltage=CMB_Voltmeter(_ADC_Values[15]);
		break;
		case 4:
			USBVoltage=CMB_Voltmeter(_ADC_Values[20]);
			if (USBVoltage > 2.0){
				Display.Flag_Sarj=true;
			}else{
				Display.Flag_Sarj=false;
			}

		break;
		case 5:
			//calismadi Display.PowerDisplay((int)(BatteryVoltage * 100));
		break;
		
		default:
			_multitask_SQ=0;
		break;
	}

}
/*
void CBM_Beep(uint8_t tick)
{
	_beepCounter=tick;
}
*/
/*
void CBM_adcValueToLocalVar(uint8_t chid){
	
	int analogVal = ADCL | (ADCH << 8);
    //uint8_t _Keyb_DataTemp;
	
	_ADC_Values[_adc_SQ]=analogVal;
	
	switch(chid)
	{
		case 4://ldr1
			LightsensorData[0]=(int)analogVal;
		break;
		case 9://ldr2
			LightsensorData[1]=(int)analogVal;
		break;
		case 14://ldr3
			LightsensorData[2]=(int)analogVal;
		break;
		case 19://ldr4
			LightsensorData[3]=(int)analogVal;
		break;


		case 5: //btn
			_Keyb_DataPIN=(unsigned int)analogVal;//keyboard pininden okunan analog bilgisini
			//_Keyb_Data
			if (_Keyb_DataPIN >1000){
				flag_NewKey=false;//hic tusa basili degil
				_Keyb_Data=0;
			}else{
				_Keyb_DataTemp=0;
				if (flag_NewKey==false){
					
					//if (_Keyb_DataPIN < 10) _Keyb_DataTemp=1;//0 	E
					//if (_Keyb_DataPIN > 500 & _Keyb_DataPIN < 520) _Keyb_DataTemp=2;//510	X
					//if (_Keyb_DataPIN > 800 & _Keyb_DataPIN < 825) _Keyb_DataTemp=3;//818	U
					//if (_Keyb_DataPIN > 845 & _Keyb_DataPIN < 860) _Keyb_DataTemp=4;//852	D
					//if (_Keyb_DataPIN > 680 & _Keyb_DataPIN < 695) _Keyb_DataTemp=5;//682	L
					//if (_Keyb_DataPIN > 760 & _Keyb_DataPIN < 775) _Keyb_DataTemp=6;//767	R
					
					if (_Keyb_DataPIN < 860){_Keyb_DataTemp=4;}
					if (_Keyb_DataPIN < 825){_Keyb_DataTemp=3;}
					if (_Keyb_DataPIN < 775){_Keyb_DataTemp=6;}
					if (_Keyb_DataPIN < 695){_Keyb_DataTemp=5;}
					if (_Keyb_DataPIN < 520){_Keyb_DataTemp=2;}
					if (_Keyb_DataPIN < 10) {_Keyb_DataTemp=1;}
					
					
					if (_Keyb_DataTemp > 0){
						flag_NewKey=true;
						_Keyb_Data=(uint8_t)_Keyb_DataTemp;
						//interrupt
						//CBM_Beep(5);
						tone(PIN_BUZZER,2000,5);
					}
					
				}
			}
			//burada buton kesmesi olusturulur
		break;
		
		case 10://boardtemperature
			//BoardTemperature=CMB_Termistor(analogVal);
		break;
		
		case 15://battery voltage
			//BatteryVoltage=CMB_Voltmeter(analogVal);
			BatteryVoltage=CMB_Voltmeter(_ADC_Values[15]);
		break;
		
		case 20://USB voltage
			//USBVoltage=CMB_Voltmeter(analogVal);
			USBVoltage=CMB_Voltmeter(_ADC_Values[20]);
			if (USBVoltage > 2.0){
				Display.Flag_Sarj=true;
			}else{
				Display.Flag_Sarj=false;
			}
			
		break;


		case 2://sag1
			LsensorData[2]=analogVal;
		break;
		case 7://sag2
			LsensorData[3]=analogVal;
		break;
		case 3://sol1
			LsensorData[0]=analogVal;
		break;
		case 8://sol2
			LsensorData[1]=analogVal;
		break;
		case 13://on sol
			LsensorData[4]=analogVal;
		break;
		case 18://arka sol
			LsensorData[6]=analogVal;
		break;
		case 12://on sag
			LsensorData[5]=analogVal;
		break;
		case 17://arka sag
			LsensorData[7]=analogVal;
		break;

		
		
		case 1:
		//
		//	if (_beepCounter > 0){
		//		_beepCounter--;
		//		digitalWrite(PIN_BUZZER,digitalRead(PIN_BUZZER)-1);
		//		if (_beepCounter == 1) digitalWrite(PIN_BUZZER,0);
		//	}
			
		break;
		
		case 6:
			//pixel led tazeleme islemi kod ritmini korumak icin kesme ile yapildi
			
			//if (flag_Pixelrefresh){
			//	CeBot_Led.show();
			//	flag_Pixelrefresh=false;
			//}
			
	
		break;
		
		case 11:
			//RTC.getTime();
			//delay(100);
		break;
		
		case 16:
			//digitalWrite(PIN_BUZZER,digitalRead(PIN_BUZZER)-1);
			//CBM_CMultitask();
		break;
		
		default:

		break;
	}
	
}
*/
// INTERRUPT
// ADC


 // Interrupt service routine for the ADC completion
 //void loop() __attribute__((optimize("-O0")));

//ISR(ADC_vect) __attribute__((optimize("-O0")));
ISR(ADC_vect){
  //
	//CBM_adcValueToLocalVar(_adc_SQ);
	//int analogVal = ADCL | (ADCH << 8);
	analogVal = ADCL | (ADCH << 8);
	_ADC_Values[_adc_SQ]=analogVal;

	ADMUX= ADMUX_Def;//ADMUX &= B11010000;//ch0
	_adc_SQ++;
	//PORTC &=0b11110011;
	switch (_adc_SQ)
	{
		case 0:
		
		break;
		
		case 1://00
			digitalWrite(PIN_S1,0);  digitalWrite(PIN_S0,0);
			//PORTC &=0b11110011;
			//
			LsensorData[0]=_ADC_Values[3];
			LsensorData[1]=_ADC_Values[8];
			LsensorData[2]=_ADC_Values[2];
			LsensorData[3]=_ADC_Values[7];
			LsensorData[4]=_ADC_Values[13];
			LsensorData[5]=_ADC_Values[12];
			LsensorData[6]=_ADC_Values[18];
			LsensorData[7]=_ADC_Values[17];
			
			LightsensorData[0]=_ADC_Values[4];
			LightsensorData[1]=_ADC_Values[9];
			LightsensorData[2]=_ADC_Values[14];
			LightsensorData[3]=_ADC_Values[19];
		break;

		case 2://00
			ADMUX |= 0B00000000;//ch0 line merkez sag (A0)
		break;
		case 3://00
			ADMUX |= 0B00000001;//ch0 line merkez sol (A1)
		break;
		case 4://00
			ADMUX |= 0B00000110;// ldr1 (A6)
		break;
		case 5://00
			ADMUX |= 0B00000111;// BTN (A7)
		break;
		
		case 6://01
			digitalWrite(PIN_S1,0);  digitalWrite(PIN_S0,1);
			//PORTC |=0b00000100;
			CBM_CMultitask();
			//
		break;
		case 7://01
			ADMUX |= 0B00000000;//line yan sag (A0)
		break;
		case 8://01
			ADMUX |= 0B00000001;// line yan sol (A1)
		break;
		case 9://01
			ADMUX |= 0B00000110;//LDR2(A6)
		break;
		case 10://01
			ADMUX |= 0B00000111;//temperature (A7)
		break;
		
		case 11://10
			digitalWrite(PIN_S1,1);  digitalWrite(PIN_S0,0);
			//PORTC |=0b00001000;
			//
		break;
		case 12://10
			ADMUX |= 0B00000000;//line on sag (A0)
		break;
		case 13://10
			ADMUX |= 0B00000001;//line on sol (A1)
		break;
		case 14://10
			ADMUX |= 0B00000110;//LDR3 (A6)
		break;
		case 15://10
			ADMUX |= 0B00000111;//battery voltage (A7)
		break;
		
		case 16://11
			digitalWrite(PIN_S1,1);  digitalWrite(PIN_S0,1);
			//PORTC |=0b00001100;
			//
		break;
		case 17://11
			ADMUX |= 0B00000000;//ch0 line arka sag (A0)
		break;
		case 18://11
			ADMUX |= 0B00000001;//ch0 line arka sol (A1)
		break;
		case 19://11
			ADMUX |= 0B00000110;//LDR4 (A6)
		break;
		case 20://11
			ADMUX |= 0B00000111;//USB voltage (A7)
		break;
		
		default:
			digitalWrite(PIN_S1,0);  digitalWrite(PIN_S0,0);
			//PORTC &=0b11110011;
			_adc_SQ=0;
		break;
	}

  // Not needed because free-running mode is enabled.
  // Set ADSC in ADCSRA (0x7A) to start another ADC conversion
  // delayus(10);
   ADCSRA |= B01000000;//set adc start bit
   //interrupts();
}
 
/*thermistor*/  
/*
	
	Vo = Vs * (R0 / ( Rt + R0 ))
	Rt = R0 * (( Vs / Vo ) - 1) 
	adcMax / adcVal = Vs / Vo 

*/
/*
double CMB_Termistor(){
	// 5V - NTC(4k7) - 10k - gnd
	//_ADC_Values[10]
	//double db_0;
	db_0 = log(((10240000 / _ADC_Values[10]) - 10000));
	db_0 = 1 / (0.001129148 + (0.000234125 + (0.0000000876741 * db_0 * db_0)) * db_0);
	db_0 = db_0 - 273.15;
	return db_0;
}  
*/
//K = 1.00 / (invT0 + invBeta*(log ( adcMax / (float) adcVal - 1.00)));
int CMB_Termistor(){
	const float adcMax = 1023.00;
	const float invT0 = 1.00 / 298.15;   // room temp in Kelvin
	const float invBeta = 1.00 / 3380.00;   // replace "Beta" with beta of thermistor
    //
	db_0  = 1.00 / (invT0 + invBeta * (log ( adcMax / (float) _ADC_Values[10] - 1.00)));
	db_0 = db_0 - 273.15;
	BoardTemperature=(int)db_0;
	return BoardTemperature;
}
/*
	(voltmeter calculation) voltmetre hesaplama
	shema:
	vin - r1 - aval - r2 - gnd
	formule:
	out= ((aval * vin)/1024) /(R2/(R1+R2))
	cebot-mini values:
	r1 4k7
	r2 4k7
	vin 5.00
	0.09 error value
*/
double CMB_Voltmeter(unsigned int analogVal){
	
	//double db_0;
	
	db_0 = (analogVal * ADC_Ref) / 1024.00;
	db_0 = db_0 / 0.5; 
	/*
	if (db_0 < 0.09)//condition 
	{
     db_0=0.00;
	} 	
	*/
	return db_0;	
}
/*
unsigned int CMB_VoltmeterMV(unsigned int analogVal){
	static volatile int hesaplanan=analogVal * ADC_Ref * 2;
	
	return hesaplanan;
}
*/

/*compass begin*/
/*HMC5883L*/
//pusula aci degerini sensorden okur ve hesaplar
/*
void CMB_Compass_Begin()
{
	//Wire.begin();
	 
	// write CONFIG_A register
	//writeReg(COMPASS_RA_CONFIG_A, COMPASS_AVERAGING_8 | COMPASS_RATE_15 | COMPASS_BIAS_NORMAL);
	// write CONFIG_B register
	//writeReg(COMPASS_RA_CONFIG_B, COMPASS_GAIN_1090);
	// write MODE register
	//Measurement_Mode = COMPASS_MODE_SINGLE;
	//writeReg(COMPASS_RA_MODE, Measurement_Mode);
	//CMB_Compass_read_EEPROM_Buffer();
	//CMB_Compass_Calibration();
	
	Wire.beginTransmission(COMPASS_DEFAULT_ADDRESS); //open communication with HMC5883
	Wire.write(0x02); //select mode register
	Wire.write(0x00); //continuous measurement mode
	Wire.endTransmission();

}
*/
/*
int CMB_GetCompass(void){
	double angle;
	
	int x,y,z; //triple axis data

	//Tell the HMC5883 where to begin reading data
	Wire.beginTransmission(COMPASS_DEFAULT_ADDRESS);
	Wire.write(0x03); //select register 3, X MSB register
	Wire.endTransmission();

	//3 eksene ait bilgiler olukur. her eksen 2 registerdir
	Wire.requestFrom(COMPASS_DEFAULT_ADDRESS, 6);
	if(6<=Wire.available()){
	x = Wire.read() << 8 | Wire.read();
	z = Wire.read() << 8 | Wire.read();
	y = Wire.read() << 8 | Wire.read();
	}
	//aci hesaplanir
	angle= atan2((double)y + y_offset,(double)x + x_offset) * (180 / 3.141592654) + 180;
	//_Compass1=int(((int)angle + _Compass1) / 2);
	_Compass1= (int)angle;
	return _Compass1;
}
*/
//pusula aci bilgisini getirir
int CB_Mini::getCompass(void){
//	return CMB_GetCompass();//_Compass1;
	double angle;
	
	int x,y,z; //triple axis data

	//Tell the HMC5883 where to begin reading data
	Wire.beginTransmission(COMPASS_DEFAULT_ADDRESS);
	Wire.write(0x03); //select register 3, X MSB register
	Wire.endTransmission();

	//3 eksene ait bilgiler olukur. her eksen 2 registerdir
	Wire.requestFrom(COMPASS_DEFAULT_ADDRESS, 6);
	if(6<=Wire.available()){
	x = Wire.read() << 8 | Wire.read();
	z = Wire.read() << 8 | Wire.read();
	y = Wire.read() << 8 | Wire.read();
	}
	//aci hesaplanir
	angle= atan2((double)y + y_offset,(double)x + x_offset) * (180 / 3.141592654) + 180;
	//_Compass1=int(((int)angle + _Compass1) / 2);
	_Compass1= (int)angle;
	return _Compass1;
}
/*compass end*/







/*motor fonksiyonlari*/
void CBM_DCMotorRun(int motorID,int pwmVal )
{
	bool dir=0;
	pinMode(PIN_M1DIR,OUTPUT);
	pinMode(PIN_M2DIR,OUTPUT);

	if (pwmVal<0){
		pwmVal=pwmVal * -1;
		dir=0;
	}else{
		dir=1;
	}

	if (pwmVal>250){pwmVal=250;}

	switch (motorID)
	{
	case 1:
		digitalWrite(PIN_M1DIR,dir);
		analogWrite(PIN_M1PWM,pwmVal);
		M1_PWM=pwmVal;
	break;
	
	case 2:
		digitalWrite(PIN_M2DIR,dir - 1);
		analogWrite(PIN_M2PWM,pwmVal);
		M2_PWM=pwmVal;
	break;
	
	default:
		digitalWrite(PIN_M1DIR,dir);
		analogWrite(PIN_M1PWM,pwmVal);
		M1_PWM=pwmVal;
		digitalWrite(PIN_M2DIR,dir - 1);
		analogWrite(PIN_M2PWM,pwmVal);
		M2_PWM=pwmVal;
	break;
	}
}
/*
void CBM_DCMotorStop(void){
	
}

void CBM_Move(){
	
}
*/

/*pixel led fonksiyonlari*/
/*
void CBM_PixelInit(void){
	CeBot_Led.setColor(0,0,0,0);
	CeBot_Led.show();
}

void CBM_PixelSet(uint8_t index, uint8_t red, uint8_t green, uint8_t blue){
	CeBot_Led.setColor(index,red,green,blue);
	CeBot_Led.show();
}
void CBM_PixelShow(void){
	CeBot_Led.show();
}
*/

/*oled*/
/*oled fonksiyonlari*/
/*
void CBM_DisplayInit(void){

}
void CBM_DisplayClear(void){

}
*/

/*DS1307*/
/*
void CBM_DS1307Init(void){

}
*/
/*DS1307*/







//*****************************************************************************
//mp3 player begin
void  MP3sendCommand(byte command, byte arg1, byte arg2){
      // Command structure
      // [7E][number bytes following including command and terminator][command byte][?arg1][?arg2][EF]
      
      // Most commands do not have arguments
      byte args = 0;
      
      // These ones do
      switch(command)
      {        
        case 0x03: args = 2; break;
        case 0x06: args = 1; break;
        case 0x07: args = 1; break;        
        case 0x09: args = 1; break;
        case 0x0F: args = 1; break;
        case 0x11: args = 1; break;
        case 0x12: args = 2; break;
      }
      
      MP3_port.write((byte)0x7E);
      MP3_port.write(2+args);
      MP3_port.write(command);
      if(args>=1) MP3_port.write(arg1);
      if(args==2) MP3_port.write(arg2);
      MP3_port.write((byte)0xEF);
      delay (200);
}
void  MP3reset()
{
  MP3sendCommand(0x0C,0,0);
  delay(1000); 
}
void MP3play()
{
  MP3sendCommand(0x0D, 0, 0 ); 
}

void  MP3setVolume(byte volumeFrom0To30)
{
  if (volumeFrom0To30 > 30 ) volumeFrom0To30=30;
  MP3sendCommand(0x06, volumeFrom0To30,0);
}

void  MP3playFile(unsigned int fileNumber)
{  
  MP3sendCommand(0x03, (fileNumber>>8) & 0xFF, fileNumber & (byte)0xFF);
}
//mp3 player end
//*****************************************************************************




























//*****************************************************************************
//CB_Mini class fonksiyonlari
CB_Mini::CB_Mini()
{
	
}

void CB_Mini::Begin(void)
{

	
}

//or bool __attribute__ ((noinline)) i2c_init(void) __attribute__ ((used));
//void __attribute__ ((noinline)) CB_Mini::RunTime(void) 
void CB_Mini::RunTime(void)
{
/*	
		//bu bolumu tasklara bol!!!
		RT_Squencer++;
		
		switch(RT_Squencer)
		{
		case 1://boardtemperature
			//BoardTemperature=CMB_Termistor();//CMB_Termistor(analogVal);
		break;
		
		case 2://battery voltage
			//BatteryVoltage=CMB_Voltmeter(_ADC_Values[15]);//CMB_Voltmeter(analogVal);
		break;
		
		case 3://USB voltage
			
			USBVoltage=CMB_Voltmeter(_ADC_Values[20]);//CMB_Voltmeter(analogVal);
			
			if (USBVoltage > 2.0){
				Display.Flag_Sarj=true;
			}else{
				Display.Flag_Sarj=false;
			}
			
		break;
		
		case 4:
			this->Show_Power();
		break;
		
		case 5:
		
		break;
		
		default:
			RT_Squencer=0;
		break;
		}
*/
}

void CB_Mini::DCMotorRun(int motorID,int pwmVal)
{
	CBM_DCMotorRun(motorID,pwmVal );//call local function
}
void CB_Mini::DCMotorStop(void)
{
	this->DCMotorRun(0,0);
}
void CB_Mini::LED(uint8_t index, uint8_t red, uint8_t green, uint8_t blue){
	CeBot_Led.setColor(index,red,green,blue);
	CeBot_Led.show();
	flag_Pixelrefresh=true;
}

void CB_Mini::Buzzer(int note, int beats){
	tone(PIN_BUZZER,(long)note,(long)beats);
	delay(beats);
}

/*
void CB_Mini::Buzzer(int note, int beats)
{
  int period = 1000000L / note;
  int pulse = period / 2;
  pinMode(PIN_BUZZER, OUTPUT);
  for (long i = 0; i < (long)beats * 250L; i += period) 
  {
    digitalWrite(PIN_BUZZER, HIGH);
    delayMicroseconds(pulse);
    digitalWrite(PIN_BUZZER, LOW);
    delayMicroseconds(pulse);
    //wdt_reset();
  }
}
*/
/*
void CB_Mini::tone(uint16_t frequency, uint32_t duration)
{
  int period = 1000000L / frequency;
  int pulse = period / 2;
  pinMode(PIN_BUZZER, OUTPUT);
  for (long i = 0; i < duration * 1000L; i += period) 
  {
    digitalWrite(PIN_BUZZER, HIGH);
    delayMicroseconds(pulse);
    digitalWrite(PIN_BUZZER, LOW);
    delayMicroseconds(pulse);
    wdt_reset();
  }
}
*/
/*
void CB_Mini::BuzzerTone(int note, int beats){
	tone(PIN_BUZZER,(long)note,(long)beats);
}
*/
void CB_Mini::BuzzerStop(void){
	noTone(PIN_BUZZER);
}
bool CB_Mini::getLineSensor(int id){
	
	return 0;//(bool)LsensorData[id];
}
unsigned int CB_Mini::getLineSensorValue(int id){
	return (unsigned int)LsensorData[id];
}
unsigned int CB_Mini::getLightSensorValue(int id){
	return (unsigned int)LightsensorData[id];
}

double CB_Mini::getBatteryVoltage(void){
	//BatteryVoltage=CMB_Voltmeter(_ADC_Values[15]);
	return (double)BatteryVoltage;
	//return CMB_VoltmeterMV(_ADC_Values[15]);
}
double CB_Mini::getUSBVoltage(void){
	//USBVoltage=CMB_Voltmeter(_ADC_Values[20]);
	return (double)USBVoltage;;
}
int CB_Mini::getTemperature(void){
	//BoardTemperature=CMB_Termistor();
	//return (double)BoardTemperature;
	return CMB_Termistor();
}
//mm olarak mesafe bilgisini getirir
double CB_Mini::getDistance(void){
	return _Distance1;
}



//CeBot mini de buton girisi ADC ye baglidir
uint8_t CB_Mini::getButton(void){
	return (uint8_t)_Keyb_Data;
}
unsigned int CB_Mini::getButtonPIN(void){
	return (unsigned int)_Keyb_DataPIN;
}
bool CB_Mini::getButtonPressed(int index){
	if (index==_Keyb_Data){
		return true;
	}else{
		return false;
	}
}	
void CB_Mini::playMP3(unsigned int fileNumber){
	MP3playFile(fileNumber);
}


//ozel ekran fonksiyonlari
//pil gostergesi
void CB_Mini::Show_Power(void){
	Display.PowerDisplay((int)(BatteryVoltage * 100));
}

//saat bilgisi

void CB_Mini::Show_Time(void){
    RTC.getTime();
    Display.drawTime(RTC.hour,RTC.minute,RTC.second,1);
}
void CB_Mini::Show_Date(void){
    RTC.getTime();
    Display.drawTime(RTC.day,RTC.month,(uint8_t) RTC.year - 2000,0);
}

void CB_Mini::ShowSpecialItem(int _id)
{
    switch (_id){
	
	//time
	case 0:
		this->Show_Time();
		//RTC.getTime();
		//Display.drawTime(RTC.hour,RTC.minute,RTC.second,1);
	break;
	
	case 1:
		this->Show_Date();
		//RTC.getTime();
		//Display.drawTime(RTC.day,RTC.month,(uint8_t) RTC.year - 2000,0);	
	break;
	case 2:
		Display.PowerDisplay((int)(BatteryVoltage * 100));	
	break;
	
	default:
	break;
	}
}

//*****************************************************************************







