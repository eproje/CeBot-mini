#ifndef CeBotmini_H
#define CeBotmini_H


/* ornek
#pragma GCC push_options
#pragma GCC optimize ("O0")

your code

#pragma GCC pop_options
veya

#pragma GCC optimize ("-O0")
#pragma GCC push_options

void setup() { }
void loop() { }

#pragma GCC pop_options
*/
//#pragma GCC optimize ("-O0")
//#pragma GCC push_options
//#pragma GCC diagnostic push
//#pragma GCC diagnostic ignored "-Wunused-parameter"
//#pragma GCC push_options
//#pragma GCC optimize ("O0")//optimizasyon kapatilsin
//#pragma GCC pop_options
/*
-Os (Arduino IDE default)
Compiled size: 19,558 bytes
Execution time: 17.8 seconds

-O0 (no optimisation at all!)
Compiled size: 31,382 bytes
Execution time: 44.7 seconds

-O1
Compiled size: 20,428 bytes
Execution time: 17.0 seconds

-O2
Compiled size: 20,500 bytes
Execution time: 12.7 seconds

-O3
Compiled size: 25,550 bytes
Execution time: 12.2 seconds
*/

#define CHIPSET ATmega_168_168P_328P 
#define BOARD_ARDUINO_UNO


/*pinler*/
/*2xDC motor*/
#define PIN_IRIN 2		// IR receiver pin (interrupt)
#define PIN_ECHO 3		// hcsr04 echo pin (interrupt)	
#define PIN_M1DIR 4
#define PIN_M1PWM 5
#define PIN_M2PWM 6
#define PIN_M2DIR 7
#define PIN_BUZZER 8
#define PIN_PowerGood 9	// power / standby control pin
#define PIN_MP3TX 10	// TX pin for JQ6500
#define PIN_TRIG 11		// HCSR04 trigger pin
#define PIN_IROUT 12	// IR transmit  pin
#define PIN_LED 13		// onboard 4xPIXEL led pin	
#define PIN_SENS0 14
#define PIN_SENS1 15
#define PIN_S0 16
#define PIN_S1 17

#define PIN_LDR 20
#define PIN_BTN 21

/*I2C DEVICES*/
//Compass only has one address
#define COMPASS_DEFAULT_ADDRESS (0x1E)  
#define OLED_DEFAULT_ADDRESS    (0x3C)  
 
#define I2C_ERROR                  (-1)



	
	#define TIMER_US 1000//50             // 50 uS timer duration 
	#define TICK_COUNTS 100//20//4000        // 200 mS worth of timer ticks

	/*interrupts*/
	//#define interrupts() sei()
	//#define noInterrupts() cli()
	
	#define int_irrec 0 //IE receiver  
	#define int_echo 1 	//US echo  
	

	/*seri port*/
	#define CBM_BAUD_RATE 115200
	/*ADC */
	/*voltmetre sabitleri*/

	//3v harici
	//#define ADC_Ref 3.0
	//#define ADMUX_Def B00110000

	//5v dahili
	#define ADC_Ref 3.30
	#define ADMUX_Def 0B00010000

	
	/*cizgi sensoru*/
	#define L_black 0
	#define Def_linecolor L_black

	//global degiskenler
	static volatile double 	BatteryVoltage;	
	static volatile int 	BoardTemperature;
	static volatile double 	USBVoltage;
	static volatile double 	_Distance1;
	static volatile int 	_Compass1;	

	
/*INCLUDES*/

	#include <Arduino.h>
	#include <Wire.h>
	//dahili kutuphaneler
	#include "CBMRGBLed.h" 	//pixel led kutuphanesi
	//CBMRGBLed CeBot_Led();	
	//robot I2C Devices
	#include "CBMOLED.h"	//oled kutuphanesi
	//CBMOLED Display;
	#include "CBMDS1307.h"	//ds1307 kutuphanesi
	//CBMDS1307 RTC;
	#include "TimerOne.h"	//timerone library
	
	

	class CB_Mini : public CBMDS1307 , public CBMOLED
	{
	public:
		CB_Mini();
		void Begin(void);
		//bool __attribute__ ((noinline)) i2c_init(void) __attribute__ ((used));
		
		void RunTime(void);//void RunTime(void);
		void DCMotorRun(int motorID,int pwmVal);
		void DCMotorStop(void);
		void LED(uint8_t index, uint8_t red, uint8_t green, uint8_t blue);
		void Buzzer(int note, int beats);
		//void Buzzer(uint16_t frequency, uint32_t duration);
		//void BuzzerTone(int note, int beats);
		void BuzzerStop(void);
		
		unsigned char ShowData[16];
		
		bool getLineSensor(int id);
		unsigned int  getLineSensorValue(int id);
		unsigned int  getLightSensorValue(int id);
		uint8_t  getButton(void);//buton bilgisini getirir
		unsigned int  getButtonPIN(void);//buton girisindeki ADC degerini getirir
		bool getButtonPressed(int index);//secili buton basilimi bilgisini getirir
	

		double getBatteryVoltage(void);
		double getUSBVoltage(void);
		int getTemperature(void);
		double getDistance(void);
		int getCompass(void);
		
		void playMP3(unsigned int fileNumber);

		//ozel ekran fonksiyonlari
		
		void Show_Power(void);//pil gostergesi
		void Show_Time(void);//saat gostergesi
		void Show_Date(void);//saat gostergesi
		
		void ShowSpecialItem(int _id);
	private:
  
	};
	
	extern CB_Mini robot;
	
#endif //