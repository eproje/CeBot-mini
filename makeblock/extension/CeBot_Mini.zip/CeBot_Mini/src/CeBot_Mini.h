#ifndef CeBotmini_H
#define CeBotmini_H
	#include <Arduino.h>
	
	#include "CBMRGBLed.h" 	//pixel led kutuphanesi
	#include "CBMOLED.h"	//oled kutuphanesi

	#include "TimerOne.h"	//timerone library
	
	#define TIMER_US 1000//50             // 50 uS timer duration 
	#define TICK_COUNTS 20//4000        // 200 mS worth of timer ticks
	

	
	
	//#include <Adafruit_GFX.h>
	//#include <Adafruit_SSD1306.h>
//	Adafruit_SSD1306 display(OLED_RESET);	
	/*pinler*/
	/*2xDC motor*/
	#define PIN_M1DIR 4
	#define PIN_M1PWM 5
	#define PIN_M2DIR 7
	#define PIN_M2PWM 6

	/*IR tranceiver*/
	#define PIN_IROUT 12
	#define PIN_IRIN 2
	/*HCSR04*/
	#define PIN_TRIG 11
	#define PIN_ECHO 3
	
	#define PIN_SENS0 14
	#define PIN_SENS1 15

	#define PIN_S0 16
	#define PIN_S1 17

	#define PIN_LDR 20
	#define PIN_BTN 21
	
	
	

	/*interrupts*/
	#define interrupts() sei()
	#define noInterrupts() cli()
	
	#define int_irrec 0 //IE receiver  
	#define int_echo 1 	//US echo  
	
	#define PIN_LED 13
	#define PIN_BUZZER 8
	/*seri port*/
	#define CBM_BAUD_RATE 115200
	
	/*cizgi sensoru*/
	#define L_black 0
	#define Def_linecolor L_black
	
	/*voltmetre sabitleri*/
	
	
	//degiskenler
	
	
	/*fonksiyonlar*/
	/*main*/
	void CBM_init(void);
	void CBM_Beep(uint8_t tick);
	/*pixel led*/
	void CBM_PixelInit(void);
	void CBM_PixelSet(uint8_t index, uint8_t red, uint8_t green, uint8_t blue);
	void CBM_PixelShow(void);
	/*oled*/
	void CBM_DisplayInit(void);
	/*motor*/
	void CBM_DCMotorRun(int motorID,int pwmVal);
	void CBM_DCMotorStop(void);
	/*hcsr04*/
	int CBM_GetDistance(void);
	/**/

	
	double CBM_GetBatteryVoltage(void);
	double CMB_Termistor(int aVal);
	double CMB_Voltmeter(int aVal);
	
	double CBM_GetTemperature(void);
	
	void CBM_adcValueToLocalVar(uint8_t chid);
	
	void CBM_adcInit();
	/**/
	void CMB_timerIsr(void);
	void CMB_echoIsr(void);
	
	void CBM_CMultitask(void);
	
	
	class CB_Mini
	{
	public:
		void DCMotorRun(int motorID,int pwmVal);
		void DCMotorStop(void);
		void LED(uint8_t index, uint8_t red, uint8_t green, uint8_t blue);
		void Buzzer(int note, int beats);
		void BuzzerStop(void);
		
		unsigned char ShowData[16];
		
		bool getLineSensor(int id);
		int  getLineSensorValue(int id);
		int  getLightSensorValue(int id);
		uint8_t  getButton(void);//buton bilgisini getirir
		int  getButtonPIN(void);//buton girisindeki ADC degerini getirir
		bool getButtonPressed(int index);//secili buton basilimi bilgisini getirir
	
		double getBatteryVoltage(void);
		double getUSBVoltage(void);
		double getTemperature(void);
		double getDistance(void);
		
	private:
  
	};
	
	
#endif //