#ifndef CeBotmini_H
#define CeBotmini_H


/* ornek
#pragma GCC push_options
#pragma GCC optimize ("O0")

your code

#pragma GCC pop_options
veya

#pragma GCC optimize ("-O0")
#pragma GCC push_options

void setup() { }
void loop() { }

#pragma GCC pop_options
*/
//#pragma GCC optimize ("-O0")
//#pragma GCC push_options
//#pragma GCC diagnostic push
//#pragma GCC diagnostic ignored "-Wunused-parameter"
//#pragma GCC push_options
//#pragma GCC optimize ("O0")//optimizasyon kapatilsin
//#pragma GCC pop_options
/*
-Os (Arduino IDE default)
Compiled size: 19,558 bytes
Execution time: 17.8 seconds

-O0 (no optimisation at all!)
Compiled size: 31,382 bytes
Execution time: 44.7 seconds

-O1
Compiled size: 20,428 bytes
Execution time: 17.0 seconds

-O2
Compiled size: 20,500 bytes
Execution time: 12.7 seconds

-O3
Compiled size: 25,550 bytes
Execution time: 12.2 seconds
*/


#include "CBMdefaults.h"


#define CHIPSET ATmega_168_168P_328P 
#define BOARD_ARDUINO_UNO





 
#define I2C_ERROR                  (-1)



	
	#define TIMER_US 1000//50             // 50 uS timer duration 
	#define TICK_COUNTS 100//20//4000        // 200 mS worth of timer ticks

	/*interrupts*/
	//#define interrupts() sei()
	//#define noInterrupts() cli()
	
	#define int_irrec 0 //IR receiver  
	#define int_echo 1 	//US echo  
	


	/*ADC */
	/*voltmetre sabitleri*/

	//3v3 harici
	//#define ADC_Ref 3.0
	//#define ADMUX_Def 0B00010000
	
	//5v dahili
	#define ADC_Ref 5.00
	#define ADMUX_Def 0B01010000

	
	/*cizgi sensoru*/
	#define L_black 0
	#define Def_linecolor L_black

	//global degiskenler
	static volatile double 	BatteryVoltage;	
	static volatile int 	BoardTemperature;
	static volatile double 	USBVoltage;
	static volatile double 	_Distance1;
	static volatile int 	_Compass1;	

	
/*INCLUDES*/

	#include <Arduino.h>
	#include <Wire.h>
	//dahili kutuphaneler
	#include "CBMRGBLed.h" 	//pixel led kutuphanesi

	//robot I2C Devices
	#include "CBMOLED.h"	//oled kutuphanesi
	#include "CBMDS1307.h"	//ds1307 kutuphanesi

	
	//#include "TimerOne.h"	//timerone kutuphanesi
	//#include "CBMIR.h"		//IR tranceiver kutuphanesi
	//CBMIR IRtranceiver;
	//CBMDS1307 RTC;
	

	class CB_Mini :  public CBMOLED, public CBMDS1307
	{
		//public:CBMDS1307;//RTC kutuphanesi public olarak tanitildi
		
		
	public:
		CB_Mini();
		
		
		void Begin(void);
		//bool __attribute__ ((noinline)) i2c_init(void) __attribute__ ((used));
		
		void RunTime(void);//void RunTime(void);
		void DCMotorRun(int motorID,int pwmVal);
		void DCMotorStop(void);
		void LED(uint8_t index, uint8_t red, uint8_t green, uint8_t blue);
		void Buzzer(int note, int beats);
		//void Buzzer(uint16_t frequency, uint32_t duration);
		//void BuzzerTone(int note, int beats);
		void BuzzerStop(void);
		
		unsigned char ShowData[16];
		
		bool getLineSensor(int id);
		unsigned int  getLineSensorValue(int id);
		unsigned int  getLightSensorValue(int id);
		uint8_t  getButton(void);//buton bilgisini getirir
		unsigned int  getButtonPIN(void);//buton girisindeki ADC degerini getirir
		bool getButtonPressed(int index);//secili buton basiliyken
		bool getButtonClick(int index);//secili butona basildiği an

		double getBatteryVoltage(void);
		double getUSBVoltage(void);
		int getTemperature(void);
		double getDistance(void);
		int getCompass(void);
		void CompassBegin(void);
		void playMP3(unsigned int fileNumber);

		//ozel ekran fonksiyonlari
		
		void Show_Power(void);//pil gostergesi
		void Show_Time(void);//saat gostergesi
		void Show_Date(void);//saat gostergesi
		
		void ShowSpecialItem(int _id);
	private:
		
  
	};
	
	extern CB_Mini robot;
	
#endif //