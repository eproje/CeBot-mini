#include "CBMIR.h"




//degiskenler
volatile irparams_t irparams;


void CMB_IRIsr(void)
{
	//digitalWrite(PIN_IROUT,digitalRead(PIN_IROUT)-1);
	digitalWrite(PIN_BUZZER,digitalRead(PIN_BUZZER)-1);
}



CBMIR::CBMIR()
{
  pinMode(PIN_IRIN,INPUT);
  irparams.recvpin = PIN_IRIN;
  // attachInterrupt(INT0, irISR, CHANGE);
  
  
  irDelayTime = 0;
  irIndex = 0;
  irRead = 0;
  irReady = false;
  irBuffer = "";
  irPressed = false;
  begin();
  
  pinMode(PIN_IROUT, OUTPUT);
  digitalWrite(PIN_IROUT, LOW); // gonderme olmadigi zaman LOW da bekletilir
}
//
void CBMIR::begin()
{
/*
  cli();
  // setup pulse clock timer interrupt
  //Prescale /8 (16M/8 = 0.5 microseconds per tick)
  // Therefore, the timer interval can range from 0.5 to 128 microseconds
  // depending on the reset value (255 to 0)
  TIMER_CONFIG_NORMAL();

  //Timer2 Overflow Interrupt Enable
  TIMER_ENABLE_INTR;

  // TIMER_RESET;

  sei();  // enable interrupts

  // initialize state machine variables
  irparams.rawlen = 0;
  irparams.rcvstate = STATE_IDLE;

  // set pin modes
  // pinMode(2, INPUT);
  // pinMode(irparams.recvpin, INPUT);
*/
attachInterrupt(INT0, CMB_IRIsr, CHANGE);

}
//
void CBMIR::end()
{
  //EIMSK &= ~(1 << INT0);IRRX_INTR_NAME
  EIMSK &= ~(1 << INT1);
  //EIMSK &= ~(1 << IRRX_INTR_NAME);
}
//

void CBMIR::sendString(String s)
{
  /*
  unsigned long l;
  uint8_t data;
  s.concat('\n');
  for(int i = 0;i < s.length();i++)
  {
    data = s.charAt(i);
    l = 0x0000ffff & (uint8_t)(~data);
    l = l << 8;
    l = l + ((uint8_t)data);
    l = l << 16;
    l = l | 0x000000ff;
    sendNEC(l,32);
    delay(20);
  }
  enableIRIn();
  */
}
//
void CBMIR::sendString(float v)
{
  /*
  dtostrf(v,5, 2, floatString);
  sendString(floatString);
  */
}

