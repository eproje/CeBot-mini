// ###########.read##################################################################
// #
// # Scriptname : CBMOLED.cpp
// # Author     : Huseyin SERIMER
// # Contributor: Yasar ASLANOGLU, Mustafa KARAKAS
// # contact    : hserimer@gmail.com
// # Date       : 2019-03-01
// # Version    : 1.00
// # License    : GNU GPLv3
// #
// # Description:
// # The CBMOLED Library
// #
// #
// # Notes...
// #
// #############################################################################

#include <Arduino.h>
#include <avr/pgmspace.h>
#include "Wire.h"
#include "CBMOLED.h"

//#include <math.h>


#ifndef OLED_DEFAULT_ADDRESS
	#define OLED_DEFAULT_ADDRESS    (0x3C) 
#endif


/*********OLED command writing***********/
void CBMOLED::WriteCommand(unsigned int ins)
{
  //Wire.beginTransmission(0x78 >> 1);//0x78 >> 1
  Wire.beginTransmission(OLED_DEFAULT_ADDRESS);
  Wire.write(0x00);//0x00
  Wire.write(ins);
  Wire.endTransmission();
}
/*********OLED data writing***********/
void CBMOLED::WriteData(unsigned int dat)
{
  //Wire.beginTransmission(0x78 >> 1 );//0x78 >> 1
  Wire.beginTransmission(OLED_DEFAULT_ADDRESS);
  Wire.write(0x40);//0x40
  Wire.write(dat);
  Wire.endTransmission();
}

/*********OLED initialization***********/
void CBMOLED::Init()
{
  Wire.begin();
  Wire.setClock(800000);

  WriteCommand(0xAE);//display off

  WriteCommand(0x00);//set lower column address
  WriteCommand(0x10);//set higher column address

  WriteCommand(0x40);//set the start line of display

  WriteCommand(0xB0);//set page address

  WriteCommand(0x81);
  WriteCommand(0xCF);//0~255��

  WriteCommand(0xA1);//set segment remap

  WriteCommand(0xA6);//normal / reverse

  WriteCommand(0xA8);//multiplex ratio
  WriteCommand(0x3F);//duty = 1/64

  WriteCommand(0xC8);//Com scan direction

  WriteCommand(0xD3);//set display offset
  WriteCommand(0x00);

  WriteCommand(0xD5);//set osc division
  WriteCommand(0x80);

  WriteCommand(0xD9);//set pre-charge period
  WriteCommand(0xF1);

  WriteCommand(0xDA);//set COM pins
  WriteCommand(0x12);

  WriteCommand(0xDB);//set VCOMH
  WriteCommand(0x40);

  WriteCommand(0x8D);//set charge pump enable
  WriteCommand(0x14);

  WriteCommand(0xAF);//display ON
}


void CBMOLED::IIC_SetPos(unsigned int x, unsigned int y)
{
  WriteCommand(0xb0 + y);
  WriteCommand(((x & 0xf0) >> 4) | 0x10); //|0x10
  WriteCommand((x & 0x0f) | 0x00); //|0x01
}
void CBMOLED::setCursor(uint8_t x, uint8_t y) 
{
  IIC_SetPos(x, y);
}

/*
void CBMOLED::setCol(uint8_t col) {
  if (col >= m_displayWidth) return;
  m_col = col;
  col += m_colOffset;
  ssd1306WriteCmd(SSD1306_SETLOWCOLUMN | (col & 0XF));
  ssd1306WriteCmd(SSD1306_SETHIGHCOLUMN | (col >> 4));
}
void CBMOLED::setCursor(uint8_t col, uint8_t row) {
  setCol(col);
  setRow(row);
}
*/
/********* CLS function ***********/
void CBMOLED::Clear() {

  //this->IIC_SetPos(0, 0);
  //Clear_Screen(0, 0, 128, 8, 0x00);
  //veya
  /*
  for (int y=0;y<8;y++)
  {
	this->IIC_SetPos(0, y);
    for (int x = 0; x < 128; x++)
    {
	  this->WriteData(0x00);
    }	
  }
  */
  //veya
  Fill_Screen(0, 0, 128, 8, 0x00);
  this->IIC_SetPos(0, 0);
  
}


/*********Screen clearing***********/
//void CBMOLED::Clear_Screen(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, unsigned int dat1)
//{
//  unsigned char x, y;
//  for (y = y0; y < y1; y++)
//  {
//    //WriteCommand(0xB0 + y);  /*set page address*/
//    //WriteCommand(0x02);      /*set lower column address*/
//    //WriteCommand(0x10);      /*set higher column address*/
//	this->IIC_SetPos(0, y);
//    for (x = x0; x < x1; x++)
//    {
//	  WriteData(dat1);
//    }
//  }
//}
/*********Display of partial screen control***********/
void CBMOLED::Fill_Screen(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, unsigned int dat1)
{
  unsigned char x, y;
  for (y = y0; y < y1; y++)
  {
    for (x = x0; x < x1; x++)
    {
      IIC_SetPos(x, y);
      WriteData(dat1);
    }
  }
}



/*********Electricity quantity display***********/
/* Batarya gostergesi*/
void CBMOLED::PowerDisplay(int Power)
{
  int ledLevel = map(Power, 350, 440, 0, 14);
//  int ledLevel = map(Power, 0, 1023, 0, 14);
	
  IIC_SetPos(107, 0);
  WriteData(0b00111100);
  WriteData(0b00100100);
  WriteData(0b00100100);
  WriteData(0b11100111);
  WriteData(0b10000001);

	for (int thisLed = 0; thisLed < 14; thisLed++) {
		if (thisLed < ledLevel) {
		  WriteData(0b10111101);
		}
		else {
		  WriteData(0b10000001);
		}
	}
	
  WriteData(0b10000001);
  WriteData(0b11111111);

  IIC_SetPos(100, 0);
  if (Flag_Sarj){
	WriteData(0b00000000);
	WriteData(0b00011100);
	WriteData(0b10011010);
	WriteData(0b01011001);
	WriteData(0b00111000);
	WriteData(0b00000000);

  }else{
	WriteData(0b00000000);
	WriteData(0b00000000);
	WriteData(0b00000000);
	WriteData(0b00000000);
	WriteData(0b00000000);
	WriteData(0b00000000);
  }
}

uint8_t CBMOLED::flipbyte(uint8_t in){
	uint8_t out = 0;
	for (int _i = 0; _i < 8; _i++) 
	{
		out <<= 1;
		if (in & 1)
		out |= 1;
		in >>= 1;
	}
	return out;
}

//2x20 lcd
void CBMOLED::PrintLCD(uint8_t y, char *str){
	uint8_t num;
	uint8_t temp2;
	
	/*
	if (line==0){
		Display.IIC_SetPos(0, 6);
	}else{
		Display.IIC_SetPos(0, 7);
	}
	*/
	
	Display.IIC_SetPos(0, y);
	for (int i=0; str[i]!= '\0';i++){
		//if(i >= STRING_DISPLAY_BUFFER_SIZE){ break; }	
		if(i < STRING_DISPLAY_BUFFER_SIZE - 1){
                for(num=0; pgm_read_byte(&Font_6x8[num].Character[0]) != '@'; num++)
                {
                    if(str[i] == pgm_read_byte(&Font_6x8[num].Character[0]))
                    {
                        for(uint8_t j=0;j<6;j++)
                        {
                            temp2=flipbyte(pgm_read_byte(&Font_6x8[num].data[j]));
							Display.WriteData(temp2);
						}
                        break;
                    }
                }
		}else{
			break;
		}
	}
}

void CBMOLED::clearBuffer()
{
    for(uint8_t i=0;i<LED_BUFFER_SIZE;i++)
    {
        u8_Display_Buffer[i] = 0x00;
    }
	
}

void CBMOLED::ClearLEDScreen()
{
	this->clearBuffer();
    Color_Index = 1;
    //ornek
	//writeBytesToAddress(0,u8_Display_Buffer,LED_BUFFER_SIZE);
	drawLedBuffer();
}
void CBMOLED::drawLedBuffer()
{
	uint8_t temp0,temp1,temp2;

	//for(uint8_t k=0;k<Bitmap_Width;k++)
	for(uint8_t k=0;k<32;k++)
	{
		temp0 =u8_Display_Buffer[k];//Bitmap[k];
		temp1=k * 4;
		
		for (uint8_t j=0; j<7; j=j+2){

			Display.IIC_SetPos(temp1, 5-(j/2));
			temp2=0;
			
			if (bitRead(temp0, j)){
				temp2 |= 0b01110000;
			}	
			if (bitRead(temp0, j+1)){
				temp2 |= 0b00000111;
			}	
				Display.WriteData(temp2);
				Display.WriteData(temp2);
				Display.WriteData(temp2);
		}
	}			
}


//void CBMOLED::drawICON(int8_t x, int8_t y, uint8_t Bitmap_Width, uint8_t *Bitmap)
void CBMOLED::drawICON(uint8_t *Bitmap)
//void CB_Mini::drawICON(void){
{
//	Display.drawBitmap(x, y, Bitmap_Width, *Bitmap);
	// ~ invert
	// ^=
	//memcpy(u8_Display_Buffer,Bitmap,16);
	/*
	for (int i=0;i<16;i++){
		u8_Display_Buffer[i]=0;
		u8_Display_Buffer[16+i]=0;
	}
	*/
	this->clearBuffer();//bufferi temizler
	
	for (int i=0;i<16;i++){
		u8_Display_Buffer[8+i]=Bitmap[i];
	}

	drawLedBuffer();
}


void CBMOLED::drawStr(const char *str)
{
	uint8_t num;
	uint8_t temp0=0;
	uint8_t temp2;
	
	//ClearLEDScreen();
	this->clearBuffer();//bufferi temizler
    /*
	for(uint8_t i=0;i<LED_BUFFER_SIZE;i++)
    {
        u8_Display_Buffer[i] = 0x00;
    }
	*/
	for (int i=0; str[i]!= '\0';i++){
		//if(i >= STRING_DISPLAY_BUFFER_SIZE){ break; }	
		if(i < 5){
                for(num=0; pgm_read_byte(&Font_6x8[num].Character[0]) != '@'; num++)
                {
                    if(str[i] == pgm_read_byte(&Font_6x8[num].Character[0]))
                    {
                        for(uint8_t j=0;j<6;j++)
                        {
                            if (temp0<LED_BUFFER_SIZE-1){
								temp2=pgm_read_byte(&Font_6x8[num].data[j]);
								//Display.WriteData(temp2);
								u8_Display_Buffer[temp0]=temp2;
								temp0++;
							}else{ break;}
						}
                        break;
                    }
                }
		}else{
			break;
		}
	}	
	
	drawLedBuffer();
}
void CBMOLED::drawNumber(const char *str){
	
	uint8_t num;
	uint8_t temp0=0;//buffer sayaci
	uint8_t b_char=0;// karakterin karsiligi
	uint8_t temp2=0;
	
	this->clearBuffer();//bufferi temizler
	for (int i=0; str[i]!= '\0';i++){
		//Serial.print(int(str[i]));
		b_char=int(str[i]);
		if ((b_char < 45) | (b_char > 57) | (b_char == 47)  ){ break;}//cik
		
		if (b_char == 45){
			b_char=0x0b;//- isareti
		}else if (b_char == 46){
			b_char=0x0a;//. isareti
		} else {
			b_char = b_char-48;
		}

		for(uint8_t j=0;j<3;j++)
		{
			if (temp0<LED_BUFFER_SIZE-1){
				u8_Display_Buffer[temp0]  =pgm_read_byte(&Font_3x8[b_char].data[j]);// pgm_read_byte(&Font_3x8[b_char%10].data[j]);
				temp0++;
			}else{ break;}
		}	
		u8_Display_Buffer[temp0]  = 0x00;
		temp0++;

	}	
//	Serial.println("");
	drawLedBuffer();	
}
	
/*
void CBMOLED::drawNumber(float value,uint8_t digits){
  uint8_t buf[8] = { 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c};
	
  u8_Display_Buffer[0]  = pgm_read_byte(&Font_3x8[buf[0]].data[0]);
  u8_Display_Buffer[1]  = pgm_read_byte(&Font_3x8[buf[0]].data[1]);
  u8_Display_Buffer[2]  = pgm_read_byte(&Font_3x8[buf[0]].data[2]);
  
  u8_Display_Buffer[3]  = 0x00;
  
  u8_Display_Buffer[4]  = pgm_read_byte(&Font_3x8[buf[1]].data[0]);
  u8_Display_Buffer[5]  = pgm_read_byte(&Font_3x8[buf[1]].data[1]);
  u8_Display_Buffer[6]  = pgm_read_byte(&Font_3x8[buf[1]].data[2]);
  
  u8_Display_Buffer[7]  = 0x00;
  
  u8_Display_Buffer[8]  = pgm_read_byte(&Font_3x8[buf[2]].data[0]);
  u8_Display_Buffer[9]  = pgm_read_byte(&Font_3x8[buf[2]].data[1]);
  u8_Display_Buffer[10]  = pgm_read_byte(&Font_3x8[buf[2]].data[2]);
  
  u8_Display_Buffer[11]  = 0x00;
  
  u8_Display_Buffer[12]  = pgm_read_byte(&Font_3x8[buf[3]].data[0]);
  u8_Display_Buffer[13]  = pgm_read_byte(&Font_3x8[buf[3]].data[1]);
  u8_Display_Buffer[14]  = pgm_read_byte(&Font_3x8[buf[3]].data[2]);

  u8_Display_Buffer[15]  = 0x00;

  u8_Display_Buffer[16]  = pgm_read_byte(&Font_3x8[buf[4]].data[0]);
  u8_Display_Buffer[17]  = pgm_read_byte(&Font_3x8[buf[4]].data[1]);
  u8_Display_Buffer[18]  = pgm_read_byte(&Font_3x8[buf[4]].data[2]);

  u8_Display_Buffer[19]  = 0x00;

  u8_Display_Buffer[20]  = pgm_read_byte(&Font_3x8[buf[5]].data[0]);
  u8_Display_Buffer[21]  = pgm_read_byte(&Font_3x8[buf[5]].data[1]);
  u8_Display_Buffer[22]  = pgm_read_byte(&Font_3x8[buf[5]].data[2]);

  u8_Display_Buffer[23]  = 0x00;

  u8_Display_Buffer[24]  = pgm_read_byte(&Font_3x8[buf[6]].data[0]);
  u8_Display_Buffer[25]  = pgm_read_byte(&Font_3x8[buf[6]].data[1]);
  u8_Display_Buffer[26]  = pgm_read_byte(&Font_3x8[buf[6]].data[2]);

  u8_Display_Buffer[27]  = 0x00;
  
  u8_Display_Buffer[28]  = pgm_read_byte(&Font_3x8[buf[7]].data[0]);
  u8_Display_Buffer[29]  = pgm_read_byte(&Font_3x8[buf[7]].data[1]);
  u8_Display_Buffer[30]  = pgm_read_byte(&Font_3x8[buf[7]].data[2]);

  u8_Display_Buffer[31]  = 0x00;
  
  drawLedBuffer();
  
  }
*/
//saat/tarih bilgisini Grafik LED olarak yazidirir
void CBMOLED::drawTime(uint8_t hour, uint8_t minute,  uint8_t second, bool point){
	
	this->clearBuffer();//bufferi temizler
	
    u8_Display_Buffer[3]  = pgm_read_byte(&Font_3x8[hour/10].data[0]);
    u8_Display_Buffer[4]  = pgm_read_byte(&Font_3x8[hour/10].data[1]);
    u8_Display_Buffer[5]  = pgm_read_byte(&Font_3x8[hour/10].data[2]);
 
    //u8_Display_Buffer[6]  = 0x00;
 
    u8_Display_Buffer[7]  = pgm_read_byte(&Font_3x8[hour%10].data[0]);
    u8_Display_Buffer[8]  = pgm_read_byte(&Font_3x8[hour%10].data[1]);
    u8_Display_Buffer[9]  = pgm_read_byte(&Font_3x8[hour%10].data[2]);
 
	//u8_Display_Buffer[11] = 0x28;
 
    u8_Display_Buffer[13]  = pgm_read_byte(&Font_3x8[minute/10].data[0]);
    u8_Display_Buffer[14] = pgm_read_byte(&Font_3x8[minute/10].data[1]);
    u8_Display_Buffer[15] = pgm_read_byte(&Font_3x8[minute/10].data[2]);

    //u8_Display_Buffer[16] = 0x00;

    u8_Display_Buffer[17] = pgm_read_byte(&Font_3x8[minute%10].data[0]);
    u8_Display_Buffer[18] = pgm_read_byte(&Font_3x8[minute%10].data[1]);
    u8_Display_Buffer[19] = pgm_read_byte(&Font_3x8[minute%10].data[2]);

	//u8_Display_Buffer[21] = 0x28;
	
    u8_Display_Buffer[23]  = pgm_read_byte(&Font_3x8[second/10].data[0]);
    u8_Display_Buffer[24] = pgm_read_byte(&Font_3x8[second/10].data[1]);
    u8_Display_Buffer[25] = pgm_read_byte(&Font_3x8[second/10].data[2]);

    //u8_Display_Buffer[26] = 0x00;

    u8_Display_Buffer[27] = pgm_read_byte(&Font_3x8[second%10].data[0]);
    u8_Display_Buffer[28] = pgm_read_byte(&Font_3x8[second%10].data[1]);
    u8_Display_Buffer[29] = pgm_read_byte(&Font_3x8[second%10].data[2]);
	
	if(point == 1)
    {
        u8_Display_Buffer[11] = 0x28;
        u8_Display_Buffer[21] = 0x28;
    }
	
	drawLedBuffer();

}
/*
void CBMOLED::drawNumber(const char *str){

}
*/


// *********************************************
// Define user object
// *********************************************
class CBMOLED Display;