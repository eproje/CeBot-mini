// #############################################################################
// #
// # Scriptname : CBMDS1307.h
// # Author     : Peter Schmelzer
// # Contributor: Oliver Kraus
// # contact    : schmelle2@googlemail.com
// # Date       : 2010-11-01
// # Version    : 0.2
// # License    : cc-by-sa-3.0
// #
// # Description:
// # Headerfile for the CBMDS1307 Library
// # 
// #############################################################################
// *********************************************
// DEFINE
// *********************************************
#ifndef CBMDS1307_h
#define CBMDS1307_h

// *********************************************
// INCLUDE
// *********************************************
#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif
  
// *********************************************
// Library interface description
// *********************************************
class CBMDS1307
{
  public:
    CBMDS1307();
    bool RTCisPresent(void);
	void SoftRTC(void);
    void startClock(void);
    void stopClock(void);
    
	void setRTCvalues(void);
	int getRTCvalue(int index);
	
    void getTime(void);

    bool setTime(uint8_t _h, uint8_t _m, uint8_t _s);
    bool setDate(uint8_t _d, uint8_t _m, uint8_t _y, uint8_t _dow);
		
    void getCTRL(void);
    void setCTRL(void);

    void getRAM(uint8_t rtc_addr, uint8_t * rtc_ram, uint8_t rtc_quantity);
    void setRAM(uint8_t rtc_addr, uint8_t * rtc_ram, uint8_t rtc_quantity);

	bool RTCisOnline;

    uint8_t second;
    uint8_t minute;
    uint8_t hour; 
    uint8_t dow;			// day of week, 0 = sunday
    uint8_t day;
    uint8_t month;
    uint8_t year;
    uint8_t ctrl;


  private:
    uint8_t dec2bcd(uint8_t num);
    uint8_t bcd2dec(uint8_t num);
	uint8_t is_leap_year(uint16_t y);
};

extern CBMDS1307 RTC;

#endif
