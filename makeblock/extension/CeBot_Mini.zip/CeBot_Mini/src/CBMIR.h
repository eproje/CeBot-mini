#ifndef CBMIR_h
#define CBMIR_h


//#include <stdint.h>
//#include <stdbool.h>
#include <Arduino.h>
#include "CBMdefaults.h"


//tanimlar
#define RAWBUF 100 // Length of raw duration buffer


#define IRTX_INTR_NAME      TIMER2_COMPA_vect
#define IRRX_INTR_NAME      INT0

// ISR State-Machine : Receiver States
#define STATE_IDLE      2
#define STATE_MARK      3
#define STATE_SPACE     4
#define STATE_STOP      5
#define STATE_OVERFLOW  6
//sistem frekansi
#ifdef F_CPU
#define SYSCLOCK F_CPU     // main Arduino clock
#else
#define SYSCLOCK 16000000  // main Arduino clock
#endif


//kullanilan pinler
//2 input
//12 out
#ifndef PIN_IRIN
	#define PIN_IRIN 2
#endif
#ifndef PIN_IROUT
	#define PIN_IROUT 12
#endif

// information for the interrupt handler
typedef struct {
  uint8_t recvpin;           		// pin for IR data from detector
  volatile uint8_t rcvstate;        // state machine
  volatile uint32_t lastTime;
  unsigned int timer;     			// 
  volatile uint8_t rawbuf[RAWBUF]; 	// raw data
  volatile uint8_t rawlen;         	// counter of entries in rawbuf
} 
irparams_t;



class CBMIR
{
	public:
		CBMIR();
		void begin();
		void end();
		
		void sendString(String s);
		void sendString(float v);
	
	private:
	
		//ErrorStatus decodeNEC();

		int16_t irIndex;	
		char irRead;
		char floatString[5];
		boolean irReady;
		boolean irPressed;
		String irBuffer;
		String Pre_Str;
		double irDelayTime;

};

#endif