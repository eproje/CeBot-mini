// #############################################################################
// #
// # Scriptname : CBMDS1307.cpp
// # Author     : 
// # Contributor: Cezeri MTAL
// # contact    : 
// # Date       : 2019-05-01
// # Version    : 1.00
// # License    : cc-by-sa-3.0
// #
// # Description:
// # The CBMDS1307 Library
// #
// # Naming Convention:
// #	get...	Get information from the DS1307 hardware
// #	set...	Write information to the DS1307 hardware
// #
// # Notes on the date calculation procedures
// #  Completly rewritten and put under GPL 2019 by Cezeri MTAL
// #
// #############################################################################
// *********************************************
// INCLUDE
// *********************************************
#include "Wire.h"
#include "CBMDS1307.h"

// *********************************************
// DEFINE
// *********************************************
#define DS1307_ID 0x68

// *********************************************
// Public functions
// *********************************************
CBMDS1307::CBMDS1307()
{
  Wire.begin();
  //this->RTCisOnline=this->RTCisPresent();
}

bool CBMDS1307::RTCisPresent(void)         // check if the device is present
{
	Wire.beginTransmission(DS1307_ID);
	Wire.write((uint8_t)0x00);
	if (Wire.endTransmission() == 0) return 1;
	return 0;
}

void CBMDS1307::stopClock(void)      // set the ClockHalt bit high to stop the rtc
{
	if(RTCisOnline){
		Wire.beginTransmission(DS1307_ID);
		Wire.write((uint8_t)0x00);         // Register 0x00 holds the oscillator start/stop bit
		Wire.endTransmission();
		Wire.requestFrom(DS1307_ID, 1);
		second = Wire.read() | 0x80;       // save actual seconds and OR sec with bit 7 (sart/stop bit) = clock stopped
		Wire.beginTransmission(DS1307_ID);
		Wire.write((uint8_t)0x00);
		Wire.write((uint8_t)second);       // write seconds back and stop the clock
		Wire.endTransmission();
	}
}

void CBMDS1307::startClock(void)     // set the ClockHalt bit low to start the rtc
{
	if(RTCisOnline){
		Wire.beginTransmission(DS1307_ID);
		Wire.write((uint8_t)0x00);         // Register 0x00 holds the oscillator start/stop bit
		Wire.endTransmission();
		Wire.requestFrom(DS1307_ID, 1);
		second = Wire.read() & 0x7f;       // save actual seconds and AND sec with bit 7 (sart/stop bit) = clock started
		Wire.beginTransmission(DS1307_ID);
		Wire.write((uint8_t)0x00);
		Wire.write((uint8_t)second);       // write seconds back and start the clock
		Wire.endTransmission();
	}
}

// RTC BCD olarak data uretir bu fonksiyon BCD-DEC cevirme isleminide yapar
void CBMDS1307::getTime(void)
{
	if(RTCisOnline){
	  Wire.beginTransmission(DS1307_ID);
	  Wire.write((uint8_t)0x00);
	  Wire.endTransmission();
	  Wire.requestFrom(DS1307_ID, 7);       // request secs, min, hour, dow, day, month, year
	//  if(Wire.available()){
		second = bcd2dec(Wire.read() & 0x7f);// aquire seconds...
		minute = bcd2dec(Wire.read());     // aquire minutes
		hour = bcd2dec(Wire.read());       // aquire hours
		dow = bcd2dec(Wire.read());        // aquire dow (Day Of Week)
		dow--;	//  correction from RTC format (1..7) to lib format (0..6). Useless, because it will be overwritten
		day = bcd2dec(Wire.read());        // aquire day
		month = bcd2dec(Wire.read());      // aquire month
		year = bcd2dec(Wire.read());       // aquire year...
	//  }
		Wire.endTransmission();
	}
}

bool CBMDS1307::setTime(uint8_t h, uint8_t m, uint8_t s )
{
	
	if ( h > 23) {return 0;}
	if ( m > 59) {return 0;}
	if ( s > 59) {return 0;}
	if(RTCisOnline){
		getTime();//once mevcut zaman okunur
		hour = h;
		minute = m;
		second = s;
		setRTCvalues();
	}else{
		hour = h;
		minute = m;
		second = s;
	}
	return 1;
	
}
bool CBMDS1307::setDate(uint8_t d_, uint8_t m_, uint8_t y_, uint8_t dow_ )
{
	
	if (d_ > 31) {return 0;}
	if (m_ > 12) {return 0;}
	if (y_ > 99) {return 0;}
	if (dow_ > 6) {return 0;}
	if(RTCisOnline){
	getTime();//once mevcut zaman okunur
	day =d_;
	month = m_;
	year = y_;
	dow = dow_;
	setRTCvalues();
	}	
	return 1;

}
// Zaman bilgisi BCD formatinda DS1307 ye gonderilir
void CBMDS1307::setRTCvalues(void)
{
  if(RTCisOnline){
	  Wire.beginTransmission(DS1307_ID);
	  Wire.write((uint8_t)0x00);
	  Wire.write(dec2bcd(second) | 0x80);	// set seconds (clock is stopped!)
	  Wire.write(dec2bcd(minute));          // set minutes
	  Wire.write(dec2bcd(hour) & 0x3f);     // set hours (24h clock!)
	  Wire.write(dec2bcd(dow+1));           // set dow (Day Of Week), do conversion from internal to RTC format
	  Wire.write(dec2bcd(day));             // set day
	  Wire.write(dec2bcd(month));           // set month
	  Wire.write(dec2bcd(year));       		// set year
	  //Wire.write(dec2bcd(year-2000));     // set year
	  Wire.endTransmission();
	  this->startClock();//saat calismaya baslasin
  }
}

//bu fonksiyon scratch uyumlulugu icin yazildi 
int CBMDS1307::getRTCvalue(int index){
	int retval=0;
	
	switch (index){
		case 1: retval=second; break;
		case 2: retval=minute; break;
		case 3: retval=hour; break;
		case 4: retval=dow; break;
		case 5: retval=day; break;
		case 6: retval=month; break;
		case 7: retval=year; break;
		default: break;
	}

	return retval;//second;
}

// DS1307 nin CTRL Registeri (0x07)
void CBMDS1307::getCTRL(void)
{
  if(RTCisOnline){
  Wire.beginTransmission(DS1307_ID);
  Wire.write((uint8_t)0x07);            // set CTRL Register Address
  Wire.endTransmission();
  Wire.requestFrom(DS1307_ID, 1);       // read only CTRL Register
  ctrl = Wire.read();                   // ... and store it in ctrl
  }
}

// DS1307 nin CTRL Registeri (0x07)
void CBMDS1307::setCTRL(void)
{
	if(RTCisOnline){
		Wire.beginTransmission(DS1307_ID);
		Wire.write((uint8_t)0x07);                      // set CTRL Register Address
		Wire.write((uint8_t)ctrl);                      // set CTRL Register
		Wire.endTransmission();
	}
}

// DS1307 icindeki RAM (max 56 Byte)
void CBMDS1307::getRAM(uint8_t rtc_addr, uint8_t * rtc_ram, uint8_t rtc_quantity)
{
	if(RTCisOnline){
  Wire.beginTransmission(DS1307_ID);
  rtc_addr &= 63;                       // avoid wrong adressing. Adress 0x08 is now address 0x00...
  rtc_addr += 8;                        // ... and address 0x3f is now 0x38
  Wire.write(rtc_addr);                 // set CTRL Register Address
  if ( Wire.endTransmission() != 0 )
    return;
  Wire.requestFrom(DS1307_ID, (int)rtc_quantity);
  /*
  while(!Wire.available())
  {
    // waiting
  }
  */
  if (Wire.available()){
	  for(int i=0; i<rtc_quantity; i++) // Read x data from given address upwards...
	  {
		rtc_ram[i] = Wire.read();       // ... and store it in rtc_ram
	  }
  }
	}
}

// Write data into RAM of the RTC Chip
void CBMDS1307::setRAM(uint8_t rtc_addr, uint8_t * rtc_ram, uint8_t rtc_quantity)
{
	if(RTCisOnline){
  Wire.beginTransmission(DS1307_ID);
  rtc_addr &= 63;                       // avoid wrong adressing. Adress 0x08 is now address 0x00...
  rtc_addr += 8;                        // ... and address 0x3f is now 0x38
  Wire.write(rtc_addr);                 // set RAM start Address 
  for(int i=0; i<rtc_quantity; i++)     // Send x data from given address upwards...
  {
    Wire.write(rtc_ram[i]);             // ... and send it from rtc_ram to the RTC Chip
  }
  Wire.endTransmission();
	}  
}

// *********************************************
// Private functions
// *********************************************
// Convert Decimal to Binary Coded Decimal (BCD)
uint8_t CBMDS1307::dec2bcd(uint8_t num)
{
  return ((num/10 * 16) + (num % 10));
}

// Convert Binary Coded Decimal (BCD) to Decimal
uint8_t CBMDS1307::bcd2dec(uint8_t num)
{
  return ((num/16 * 10) + (num % 16));
}

/*
  Prototype:
    uint8_t CBMDS1307::is_leap_year(uint16_t y)
  Description:
    Calculate leap year
  Arguments:
    y   		year, e.g. 2011 for year 2011
  Result:
    0           not a leap year
    1           leap year
*/
uint8_t CBMDS1307::is_leap_year(uint16_t y)
{
  //uint16_t y = year;
   if ( 
          ((y % 4 == 0) && (y % 100 != 0)) || 
          (y % 400 == 0) 
      )
      return 1;
   return 0;
}



void CBMDS1307::SoftRTC(){
	second += 1;
	if (second>59){
		second=0;
		minute+=1;
		if (minute > 59){
			minute=0;
			hour+=1;
			if (hour>23){
				hour=0;
			}
		}
	}
}
// *********************************************
// Define user object
// *********************************************
class CBMDS1307 RTC;
