
/*pinler*/
/*2xDC motor*/
#define PIN_IRIN 2			// IR receiver pin (interrupt)
#define PIN_ECHO 3			// hcsr04 echo pin (interrupt)	
#define PIN_M1DIR 4
#define PIN_M1PWM 5
#define PIN_M2PWM 6
#define PIN_M2DIR 7
#define PIN_BUZZER 8
#define PIN_IROUT  9		// IR transmit  pin 
#define PIN_MP3TX 10		// TX pin for JQ6500
#define PIN_TRIG 11			// HCSR04 trigger pin
#define PIN_PowerGood 12	// power / standby control pin	
#define PIN_LED 13			// onboard 4xPIXEL led out pin	
#define PIN_SENS0 14
#define PIN_SENS1 15
#define PIN_S0 16
#define PIN_S1 17

#define PIN_LDR 20
#define PIN_BTN 21

/*I2C DEVICES*/
//Compass only has one address
/*HMC5883L or QMC5883L*/ 

#define COMPASS_DEVICE_NAME 0 //0:QMC 1:HMC

//0:QMC 1:HMC
#if COMPASS_DEVICE_NAME == 0
	#define COMPASS_DEFAULT_ADDRESS (0x0D) 

	#define Mode_Standby    0b00000000
	#define Mode_Continuous 0b00000001

	#define ODR_10Hz        0b00000000
	#define ODR_50Hz        0b00000100
	#define ODR_100Hz       0b00001000
	#define ODR_200Hz       0b00001100

	#define RNG_2G          0b00000000
	#define RNG_8G          0b00010000

	#define OSR_512         0b00000000
	#define OSR_256         0b01000000
	#define OSR_128         0b10000000
	#define OSR_64          0b11000000
	
#else
	#define COMPASS_DEFAULT_ADDRESS (0x1E) 
#endif

 
/*ssd1306 monocolor oled 128*64*/
#define OLED_DEFAULT_ADDRESS    (0x3C) 

/*seri port*/
#define CBM_BAUD_RATE 115200 

